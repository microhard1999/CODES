Journal: Swarm and Evolutionary Computation

Title:  An Improved Ensemble Particle Swarm Optimizer Using Niching Behavior and Covariance Matrix Adapted Retreat Phase