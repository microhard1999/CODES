% bounding function
% =========================================================================

function x = han_boun (x, xmax, xmin,PopSize)

        x_L = repmat(xmin, PopSize, 1);
        pos = x < x_L; %Less than lower bound
        x_U = repmat(xmax, PopSize, 1);
        x(pos) = xmin+0.25*(xmax-xmin)*rand;
        pos = x > x_U; %Greater than upper bound
        x(pos) = xmax-0.25*(xmax-xmin)*rand;
end  
