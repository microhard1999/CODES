% CMAR algorithm (Refer to the EBOwithCMAR code)
% =========================================================================
function[ x, fitx, setting,fitness,current_eval] = ...
    Scout( x, ~, prob, setting, iter,fitness,xmin,xmax,n,PopSize,current_eval,I_fno)
    
fitness.raw = NaN(1, PopSize);

%% select the distribution
if rand < 1*prob(1)
arz = sqrt(pi)*(asin(rand(n,PopSize))+asin(-rand(n,PopSize)));
else
arz = sqrt(pi)*asin(2*rand(n,PopSize)-1);
end

%% updating individual 
arx = repmat(setting.xmean, 1, PopSize) + setting.sigma * (setting.BD * arz);

%% using bounding function
    arxvalid =han_boun(arx', xmax, xmin, PopSize);
    arxvalid=arxvalid';
x;
%% evaluate and update cfe
fitness.raw = benchmark_func(arxvalid,I_fno);
current_eval=current_eval+PopSize; %% increase the fitness evaluations

fitness.sel= fitness.raw ;
[fitness.sel, fitness.idxsel] = sort(fitness.sel);

fitness.raw= fitness.raw(fitness.idxsel);
arxvalid= arxvalid(:, fitness.idxsel);
arx= arx(:, fitness.idxsel);
arz=arz(:, fitness.idxsel);
[~,pos_ro]=min(fitness.raw);

%% setting.weights
setting.weights = fitness.raw(1:setting.mu)';%./sum(fitness.raw(1:setting.mu));
if sum(setting.weights)>1e25
    setting.weights = 1/setting.mu*ones(setting.mu,1);
end
setting.weights = setting.weights/sum(setting.weights);     % normalize recombination setting.weights array
setting.weights = fliplr(setting.weights);

%% Calculate new setting.xmean, this is selection and recombination
setting.xold = setting.xmean; % for speed up of Eq. (2) and (3)
cmean =1;% 1/min(max((PopSize-1*n)/2, 1), n);  % == 1/kappa
setting.xmean = (1-cmean) * setting.xold + cmean * arx(:,(1:setting.mu))*setting.weights;

%% using bounding function
setting.xmean =han_boun(setting.xmean', xmax, xmin,1);
setting.xmean=setting.xmean';

zmean = arz(:,(1:setting.mu))*setting.weights;%==D^-1*setting.B'*(setting.xmean-setting.xold)/setting.sigma
%% Cumulation: update evolution paths
setting.ps = (1-setting.cs)*setting.ps + sqrt(setting.cs*(2-setting.cs)*setting.mueff) * (setting.B*zmean);          % Eq. (4)
hsig = norm(setting.ps)/sqrt(1-(1-setting.cs)^(2*iter))/setting.chiN < 1.4 + 2/(n+1);

setting.pc = (1-setting.cc)*setting.pc ...
    + hsig*(sqrt(setting.cc*(2-setting.cc)*setting.mueff)/setting.sigma/cmean) * (setting.xmean-setting.xold);     % Eq. (2)

%% Adapt covariance matrix
neg.ccov = 0;  % TODO: move parameter setting upwards at some point
if setting.ccov1 + setting.ccovmu > 0                                                    % Eq. (3)

        arpos = (arx(:,(1:setting.mu))-repmat(setting.xold,1,setting.mu)) / setting.sigma;
        setting.C = (1-setting.ccov1-setting.ccovmu) * setting.C ... % regard old matrix
            + setting.ccov1 * setting.pc*setting.pc' ...     % plus rank one update
            + setting.ccovmu ...             % plus rank setting.mu update
            * arpos * (repmat(setting.weights,1,n) .* arpos');
       
        setting.diagC = diag(setting.C);
end

%% Adapt setting.sigma
setting.sigma = setting.sigma * exp(min(1, (sqrt(sum(setting.ps.^2))/setting.chiN - 1) * setting.cs/setting.damps));             % Eq. (5)

%% Update setting.B and D from setting.C

if  (setting.ccov1+setting.ccovmu+neg.ccov) > 0 && mod(iter, 1/(setting.ccov1+setting.ccovmu+neg.ccov)/n/10) < 1
    setting.C=triu(setting.C)+triu(setting.C,1)'; % enforce symmetry to prevent complex numbers
    [setting.B,tmp] = eig(setting.C);     % eigen decomposition, setting.B==normalized eigenvectors
    % effort: approx. 15*n matrix-vector multiplications
    setting.diagD = diag(tmp);
    
    if min(setting.diagD) <= 0
        
        setting.diagD(setting.diagD<0) = 0;
        tmp = max(setting.diagD)/1e14;
        setting.C = setting.C + tmp*eye(n,n); setting.diagD = setting.diagD + tmp*ones(n,1);
        
    end
    if max(setting.diagD) > 1e14*min(setting.diagD)
        
        tmp = max(setting.diagD)/1e14 - min(setting.diagD);
        setting.C = setting.C + tmp*eye(n,n); setting.diagD = setting.diagD + tmp*ones(n,1);
        
    end
    
    setting.diagC = diag(setting.C);
    setting.diagD = sqrt(setting.diagD); % D contains standard deviations now
    setting.BD = setting.B.*repmat(setting.diagD',n,1); % O(n^2)
end % if mod

%% print out final results
x= arxvalid';
fitx= fitness.raw;




