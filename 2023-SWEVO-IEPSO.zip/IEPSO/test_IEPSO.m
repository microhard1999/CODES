clear all;
clc;

func_cnt=25;  %numbers of function 
runs=30;  %run times
result=zeros(runs,func_cnt);

load Bounds;

for i=1:5 % problem
   
    fprintf('Problem =\t %d\n',i);
    range=Bounds(i,:);
    
    for j=1:30  % runs
        func_num=i;
        fprintf('run =\t %d\n',j);      
       [Error]= IEPSO(140,range,30,2143,300000,func_num);
       result(j,i)=Error;
    end 

end    
