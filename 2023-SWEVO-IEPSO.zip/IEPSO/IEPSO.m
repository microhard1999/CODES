% main IEPSO algorithm
% =========================================================================

function [Error]= IEPSO(NP,range,dim,it_max,max_FES,func_num)

load fbias_data;

Xmax = range(2)*ones(1,dim);   % position interval
Xmin = range(1)*ones(1,dim);
Vmax = (Xmax - Xmin) / 2;     % velocity interval
Vmin = -Vmax;

fitcount=0; % init the FEs

%% Individual initialization
interval=range(2)-range(1);
v_max=Vmax; 
v_min=Vmin;

pos = range(1)+ interval.*rand(NP,dim);    % Initial position
V =Vmin+(Vmax-Vmin).*rand(NP,dim); % Initial velocity

% evaluation
fitness=benchmark_func_org(pos,func_num);
fitcount=fitcount+NP;

[gbest_val,gbest_index]=min(fitness);
gbest_pos=pos(gbest_index,:);

pbest_pos=pos;
pbest_val=fitness;


%% Parameter initialization
max_iteration=it_max;
dimension=dim;

range_min=range(1)*ones(NP,dimension); % Range for initial swarm's elements
range_max=range(2)*ones(NP,dimension);

% Niching PSO
w=0.5;
c0_1=2;
c0_2=2;

% Method: CLPSO
c1=3-(1:max_iteration)*1.5/max_iteration;
w1=0.9-(1:max_iteration)*(0.5/max_iteration);

% Sa-PSO (PSO/FDR/HPSO/LIPS/CLPSO-gbest)
w2=0.9-(1:max_iteration)*(0.7/max_iteration);

% PSO
c2_1=2.5-(1:max_iteration)*2/max_iteration;
c2_2=0.5+(1:max_iteration)*2/max_iteration;

% FDR_PSO
fii=[1 1 2];

% HPSO_TVAC
c3_1=2.5-(1:max_iteration)*2/max_iteration;
c3_2=0.5+(1:max_iteration)*2/max_iteration;
re_init_vel=range(2)-(1:max_iteration)*(0.9*range(2))/max_iteration;

% LIPS
nsize=3;

% CLPSO-gbest
c4_1=2.5-(1:max_iteration)*2/max_iteration;
c4_2=0.5+(1:max_iteration)*2/max_iteration;
obj_func_slope=zeros(NP,1);
fri_best=(1:NP)'*ones(1,dimension);
j=0:(1/(NP-1)):1; 
j=j*10;
Pc=ones(dimension,1)*(0.0+((0.5).*(exp(j)-exp(j(1)))./(exp(j(NP))-exp(j(1))))); 

num_strategy=5;

% Number of subpopulation individuals
NP1=0.1*NP;
NP2=0.7*NP;
NP3=0.2*NP;

k=0;
LP=50;

%% preparation of CLPSO
for i=NP1+1:NP1+NP2
    fri_best(i,:)=i*ones(1,dimension);
    friend1=ceil(NP2*rand(1,dimension)+NP1);
    friend2=ceil(NP2*rand(1,dimension)+NP1);
    if pbest_val(friend1)<pbest_val(friend2)
        friend=friend1;
    else
        friend=friend2;
    end
    
    toss=ceil(rand(1,dimension)-Pc(:,i)');
    if toss==ones(1,dimension)
        temp_index=randperm(dimension);
        toss(1,temp_index(1))=0;
        clear temp_index;
    end
    fri_best(i,:)=(1-toss).*friend+toss.*fri_best(i,:);
    for d=1:dimension
        fri_best_pos(i,d)=pbest_pos(fri_best(i,d),d);
    end
end
  
%% preparation of CMAR
setting=[];
fitness_temp=[];
[setting]= init_cma_par(setting,pos(1:NP1,:),dim,NP1);


%% start
while k<=it_max &&fitcount<=max_FES
    k=k+1;
 
   %% Generate sample pool
   sub_NP=zeros(NP,1);
   sub_cnt=0;
   
   for i=1:NP
       pi=1-(fitness(i)-min(fitness))/(max(fitness)-min(fitness));
       if rand<pi
           sub_cnt=sub_cnt+1;
           sub_NP(sub_cnt)=i;
       end
   end
   
   if sub_cnt==0
       sub_cnt=sub_cnt+1;
       [~,gbest_ids]=min(pbest_val);
       sub_NP(sub_cnt)=gbest_ids;
   end
   
   
%% select one particle from sample pool for CMAR group
       iiddss1=randperm(sub_cnt,1);
       iiddss1=sub_NP(iiddss1);
       iiddss2=randperm(NP1,1);

       pos(iiddss2,:)=pos(iiddss1,:);
       V(iiddss2,:)=V(iiddss1,:);
       fitness(iiddss2)=fitness(iiddss1);
       pbest_pos(iiddss2,:)=pbest_pos(iiddss1,:);
       pbest_val(iiddss2)=pbest_val(iiddss1);

%% Group1:CMAR subgroup
  [ pos(1:NP1,:),fitness(1:NP1),setting,fitness_temp,fitcount] =...
    Scout( pos(1:NP1,:),fitness(1:NP1), [0.5 0.5], setting,1,fitness_temp,range(1),range(2),dim,NP1,fitcount,func_num);
 
  % updating the global best
  [gvalue,gids]=min(fitness(1:NP1));
  if gvalue<gbest_val
      gbest_val=gvalue;
      gbest_pos=pos(gids,:);
  end
  
  if fitcount>=max_FES
      break;
  end
       
%% Group2:large population of EPSO
        gbest_pos_temp=repmat(gbest_pos,NP,1);
        
        for i=NP1+1:NP1+NP2
            if k <=1
                pk = ones(1,5)*1/num_strategy;
                rk = 0:1/num_strategy:1;
                success_mem = zeros(1,num_strategy);
                failure_mem = zeros(1,num_strategy);
                sk = zeros(1,num_strategy);
            elseif mod(fitcount,LP)==0
                total = (success_mem+failure_mem);
                total(find(total==0))=1;
                sk = (success_mem./total)+0.01;
                pk = sk./sum(sk);
                rk = [0 cumsum(pk)];
                success_mem = zeros(1,num_strategy);
                failure_mem = zeros(1,num_strategy);   
            end  
            probability = rand(1);   
                     
           if probability>= rk(1) && probability < rk(2)
                % PSO  
%                 fprintf('PSO\n');
                strategy_k = 1;
                delta(i,:)=c2_1(k).*rand(1,dimension).*(pbest_pos(i,:)-pos(i,:))+c2_2(k).*rand(1,dimension).*(gbest_pos_temp(i,:)-pos(i,:));
                V(i,:)=w2(k).*V(i,:)+delta(i,:); 
                
            elseif probability>= rk(2) && probability < rk(3)   
                % FDR-PSO
%                 fprintf('FDR_PSO\n')
                strategy_k=2;
                dis=abs(repmat(pbest_pos(i,:),NP2,1)-pbest_pos(NP1+1:NP1+NP2,:));
                
                fiterr=repmat(pbest_val(i),NP2,1)-pbest_val(NP1+1:NP1+NP2);
                
                fiterr=repmat(fiterr,1,dimension);
                if dis==zeros(NP2,dimension)
                    fiterr=0;
                end
                
               if dis==zeros(NP2,dimension)
                   dis=dis+1;
               end
               
                FDR=fiterr./dis;
                [fdr,Fid]=max(FDR);
                for dimcnt=1:dimension
                    Pnd(i,dimcnt)=pbest_pos(Fid(dimcnt),dimcnt);
                end
                delta(i,:)=fii(1).*rand(1,dimension).*(pbest_pos(i,:)-pos(i,:))+fii(2).*rand(1,dimension).*(gbest_pos_temp(i,:)-pos(i,:))+fii(3).*rand(1,dimension).*(Pnd(i,:)-pos(i,:));
                V(i,:)=w2(k).*V(i,:)+delta(i,:); 
   
            elseif probability>= rk(3) && probability < rk(4)   
                % HPSO
%                 fprintf('HPSO\n');
                strategy_k = 3;
                V(i,:)=(c3_1(k).*rand(1,dimension).*(pbest_pos(i,:)-pos(i,:)))+(c3_2(k).*rand(1,dimension).*(gbest_pos_temp(i,:)-pos(i,:)));
                for d=1:dimension
                    if V(i,d)==0
                        if (rand(1)<0.5)
                            V(i,d)=rand(1)*re_init_vel(k);
                        else
                            V(i,d)=-rand(1)*re_init_vel(k);
                        end
                    end
                    V(i,d)=sign(V(i,d))*min(abs(V(i,d)),range(2));
                end
             
            elseif probability>= rk(4) && probability < rk(5)
                    %LIPS
%                     fprintf('LIPS\n');
                    strategy_k = 4;
                    EU_dist=dist(pos(i,:),pbest_pos'); 
                    EU_dist(i)=max(EU_dist);
                    [min_dist,min_index]=sort(EU_dist); 
                    fi=(4.1./nsize).*rand(nsize,dimension);
                    FIP=sum(fi.*pbest_pos(min_index(1:nsize),:))./sum(fi);  
                    delta(i,:)=sum(fi).*(FIP-pos(i,:));
                    V(i,:)=0.7298.*(V(i,:)+delta(i,:));
%              
           elseif probability>= rk(5) && probability < rk(6)
                    %CLPSO
%                     fprintf('CLPSO\n');
                    strategy_k = 5;                          
                    delta(i,:)=(c4_1(k).*rand(1,dimension).*(fri_best_pos(i,:)-pos(i,:)))+(c4_2(k).*rand(1,dimension).*(gbest_pos_temp(i,:)-pos(i,:)));
                    V(i,:)=w2(k)*V(i,:)+delta(i,:);

                     if obj_func_slope(i)>5
                       fri_best(i,:)=i*ones(1,dimension);
                       friend1=(ceil(NP2*rand(1,dimension))+NP1);
                       friend2=(ceil(NP2*rand(1,dimension))+NP1);
                        if pbest_val(friend1)<pbest_val(friend2)
                            friend=friend1;
                        else
                            friend=friend2;
                        end
                       
                       toss=ceil(rand(1,dimension)-Pc(:,i)');
                       if toss==ones(1,dimension)
                          temp_index=randperm(dimension);
                          toss(1,temp_index(1))=0;
                          clear temp_index;
                       end
                        fri_best(i,:)=(1-toss).*friend+toss.*fri_best(i,:);
                        for d=1:dimension
                            fri_best_pos(i,d)=pbest_pos(fri_best(i,d),d);
                        end
                        obj_func_slope(i)=0;
                    end                                                            
           end
            
                  V(i,:)=((V(i,:)<v_min(1,:)).*v_min(1,:))+((V(i,:)>v_max(1,:)).*v_max(1,:))+(((V(i,:)<v_max(1,:))&(V(i,:)>v_min(1,:))).*V(i,:));            
                  pos(i,:)=pos(i,:)+V(i,:);

               if (sum(pos(i,:)>range_max(i,:))+sum(pos(i,:)<range_min(i,:))==0)
            
                   fitness(i)=benchmark_func_org(pos(i,:),func_num); 
                   fitcount=fitcount+1;
                 
                   if fitcount>=max_FES
                       break;
                   end
                   
                   if  fitness(i)<pbest_val(i) % update pbest value and position
                        pbest_pos(i,:)=pos(i,:);   
                        pbest_val(i)=fitness(i);
                        success_mem(strategy_k) = success_mem(strategy_k) +1;
                   else
                        failure_mem(strategy_k) = failure_mem(strategy_k) + 1;
                   end
                   
                   if strategy_k==5 && fitness(i)<pbest_val(i)
                       obj_func_slope(i)=0;
                   else
                       obj_func_slope(i)=obj_func_slope(i)+1;
                   end
                    
                   if  pbest_val(i)<gbest_val % update gbest value and postion
                        gbest_pos=pbest_pos(i,:); 
                        gbest_val=pbest_val(i);
                   end   
               end
        end
        
 
%% select one particle from sample pool for Niching-based iw-PSO group
           iiddss1=randperm(sub_cnt,1);
           iiddss1=sub_NP(iiddss1);
           iiddss2=randperm(NP3,1)+NP1+NP2;

           pos(iiddss2,:)=pos(iiddss1,:);
           V(iiddss2,:)=V(iiddss1,:);
           fitness(iiddss2)=fitness(iiddss1);
           pbest_pos(iiddss2,:)=pbest_pos(iiddss1,:);
           pbest_val(iiddss2)=pbest_val(iiddss1);
       
%% Group3:Niching-based iw-PSO��
            D=zeros(NP);
            for i=NP1+NP2+1:NP
                for j=i+1:NP
                    D(i,j)=sqrt(sum((pos(i,:)-pos(j,:)).^2));
                    D(j,i)=D(i,j);
                end
            end

            [~,group_best]=min(fitness(NP1+NP2+1:NP));
            sum_temp=0;
            for i=NP1+NP2+1:NP
                if i~=group_best
                    sum_temp=sum_temp+pdist2(pos(i,:),pos(group_best,:));
                end
            end
            r=sum_temp/(NP3-1); % Calculate the niche radius

            for i=NP1+NP2+1:NP
                u=[];
                for j=NP1+NP2+1:NP
                    if D(i,j)<=r
                        u=[u j];
                    end
                end
                CH{i,1}=u;
            end

            gbest_niche=zeros(NP,dim);

            for i=NP1+NP2+1:NP
                u=CH{i,1};
                fm=fitness(u);
                [value,index]=min(fm);
                gbest_niche(i,:)=pos(u(index),:); % select the niching best
            end

            [~,global_best_index]=min(fitness);

            for i=NP1+NP2+1:NP
                if rand> k/it_max
                    delta=c0_1*rand*(pbest_pos(i,:)-pos(i,:))+c0_2*rand*(gbest_niche(i,:)-pos(i,:));
                else
                    delta=c0_1*rand*(pbest_pos(i,:)-pos(i,:))+c0_2*rand*(pos(global_best_index,:)-pos(i,:));
                end

                V(i,:)=w*V(i,:)+delta;
                V(i,:)=((V(i,:)<v_min(1,:)).*v_min(1,:))+((V(i,:)>v_max(1,:)).*v_max(1,:))+(((V(i,:)<v_max(1,:))&(V(i,:)>v_min(1,:))).*V(i,:));

                pos(i,:)=pos(i,:)+V(i,:);

                % bounding function
                for j=1:dim
                    if pos(i,j)<range(1)
                        pos(i,j)=range(1)+0.25*(range(2)-range(1))*rand;
                    elseif pos(i,j)>range(2)
                        pos(i,j)=range(2)-0.25*(range(2)-range(1))*rand;
                    end
                end

                fitness(i)=benchmark_func_org(pos(i,:),func_num);
                fitcount=fitcount+1;

                if fitcount>=max_FES
                    break;
                end

                if  fitness(i)<pbest_val(i) % update pbest value and position
                    pbest_pos(i,:)=pos(i,:);
                    pbest_val(i)=fitness(i);
                end

                if  pbest_val(i)<gbest_val % update gbest value and postion
                    gbest_pos=pbest_pos(i,:);
                    gbest_val=pbest_val(i);
                end

            end
       
         
     if fitcount>=max_FES
      break;
     end 
        
   if (k==max_iteration)&&(fitcount<max_FES)
       k=k-1;
   end
   
end
Error=gbest_val-f_bias(func_num);

end