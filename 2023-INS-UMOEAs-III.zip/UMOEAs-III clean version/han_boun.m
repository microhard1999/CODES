function x = han_boun (x,xmax,xmin,x2,PopSize,hb)

switch hb
    case 1 % for DE
        ratio = 0.5;

        % Repair violations of the lower bounds.
        x_L = repmat(xmin, PopSize, 1);
        pos = x < x_L;
        x(pos) = x2(pos)+ ratio*(x_L(pos) - x2(pos));

        % Repair violations of the upper bounds.
        x_U = repmat(xmax, PopSize, 1);
        pos = x > x_U;
        x(pos) = x2(pos) + ratio*(x_U(pos) - x2(pos));

    case 2 % for CMA-ES
        % Construct element-wise bound matrices for the complete population.
        x_L = repmat(xmin, PopSize, 1);
        x_U = repmat(xmax, PopSize, 1);

        % Apply the smooth transform only where both bounds are finite and define a nonempty interval. Unsupported coordinates remain unchanged.
        finite_box = isfinite(x_L) & isfinite(x_U) & x_U > x_L;
        if any(finite_box(:))
            % Work on compact vectors containing only valid bounded entries.
            lo = x_L(finite_box);
            hi = x_U(finite_box);
            y = x(finite_box);

            % Standard lin-quad margin rule used by pycma BoundTransform.
            % The central feasible region is left unchanged, whereas narrow bands around both bounds are mapped by quadratic functions.
            al = min((hi-lo)/2,0.05*max(1,abs(lo)));
            au = min((hi-lo)/2,0.05*max(1,abs(hi)));
            left = lo-al;
            right = hi+au;
            width = right-left;

            % Periodically reflect distant samples into the extended interval [left, right]. 
            % The modulo phase avoids iterative clipping and correctly handles arbitrarily large bound violations.
            outside = y < left | y > right;
            phase = mod(y(outside)-left(outside),2*width(outside));
            y(outside) = left(outside) ...
                + min(phase,2*width(outside)-phase);

            % Map both boundary bands smoothly into [lo, hi]. 
            % The quadratic pieces join the identity region continuously with matching first derivatives, avoiding the discontinuity of hard clipping.
            below = y < lo+al;
            above = y > hi-au;
            y(below) = lo(below)+(y(below)-left(below)).^2./(4*al(below));
            y(above) = hi(above)-(y(above)-right(above)).^2./(4*au(above));

            % Scatter the repaired coordinates back into the population.
            x(finite_box) = y;
        end

end
