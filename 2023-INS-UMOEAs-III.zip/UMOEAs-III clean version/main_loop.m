clc
RecordFEsFactor = 0.001:0.001:1;
progress = numel(RecordFEsFactor);
%%
for D = [10 30 50 100]
    outcome10D=zeros(51,30);
    result=zeros(30,5);
    for I_fno=1:30
        allerrorvals = zeros(progress, 51);
        for run=1:51
            fprintf('run =\t %d function =%d dim =\t %d\n',run,I_fno,D);
            All_Fit = [];
            [All_Fit,bestold]=UMOEAsIII(run,I_fno,All_Fit,D);
            errorfit = All_Fit(round(RecordFEsFactor*size(All_Fit,1)));
            allerrorvals(:, run) = errorfit'-I_fno*100;
            outcome10D(run,I_fno) = bestold;
        end
        file_name1=sprintf('plot\\UMOEAs-III_%s_%s.txt',int2str(I_fno),int2str(D));
        save(file_name1, 'allerrorvals', '-ascii');

        result(I_fno,1)=min(outcome10D(:,I_fno));
        result(I_fno,2)=max(outcome10D(:,I_fno));
        result(I_fno,3)=median(outcome10D(:,I_fno));
        result(I_fno,4)=mean(outcome10D(:,I_fno));
        result(I_fno,5)=std(outcome10D(:,I_fno));

        file_name=sprintf('result\\UMOEAs-III_%sD.mat',int2str(D));
        save(file_name,'outcome10D');

        name1 = 'result\\results_stat_';
        name2 = num2str(D);
        f_name=strcat(name1,name2);
        save(f_name, 'result');
    end
end