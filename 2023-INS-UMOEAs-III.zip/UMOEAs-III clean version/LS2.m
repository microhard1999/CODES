function [x,f,current_eval,succ] = LS2 (bestx,f,current_eval,I_fno,Max_FES,xmin,xmax)
global_left_FE = Max_FES - current_eval;
LS_FE = ceil(20.0000e-003*Max_FES ); %% Max FFEs_LS
remaining_FEs = min(LS_FE, global_left_FE);
local_eval_limit = current_eval + LS_FE;

if remaining_FEs <= 0
    x = bestx;
    succ = 0;
    return;
end

options=optimset('Display','off','algorithm','sqp','UseParallel','never','MaxFunEvals',remaining_FEs) ;
[Xsqp, FUN, ~] = fmincon(@safe_cec17, bestx(1,:)', [],[],[],[], xmin, xmax, [], options);

% check if there is an improvement in the fitness value and update P_{ls}
if (f-FUN)>0
    succ=1;
    f = FUN;
    x(1,:)=Xsqp;
else
    succ=0;
    x=bestx;

end

    function fit_val = safe_cec17(x_test)
        if current_eval >= local_eval_limit
            % If FES is exhausted, return a very large value to "trick" fmincon into stopping exploration
            fit_val = realmax('double');
        else
            fit_val = cec17_func(x_test, I_fno);
            current_eval = current_eval + 1;
        end
    end
end


