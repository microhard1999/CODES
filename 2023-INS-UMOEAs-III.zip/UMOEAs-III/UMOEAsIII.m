function outcome= UMOEAsIII(run,I_fno,n)
Par= Introd_Par(I_fno,n);
iter=0;             %% current generation
rand('seed', sum(100 * clock));
%% define variables
current_eval=0;             %% current fitness evaluations
PS1=Par.PopSize;            %% define PS1
PS2=4+floor(3*log(n));  %% define PS2
Par.PopSize=PS1+PS2;        %% PS = PS1+PS2

%% ====================== Initalize x ==================================
x=repmat(Par.xmin,Par.PopSize,1)+repmat((Par.xmax-Par.xmin),Par.PopSize,1).*rand(Par.PopSize,n);

%% calc. fit. and update FES
fitx = cec17_func(x',I_fno);
%% ====================== store the best ==================
[bestold, bes_l]=min(fitx);     bestx= x(bes_l,:);
current_eval=current_eval+Par.PopSize;

%% ================== fill in each MOEA ===================================
%% DE
EA_1= x(1:PS1,:);    EA_obj1= fitx(1:PS1);
genDE=0; 
%% ES
EA_2= x(PS1+1:size(x,1),:);    EA_obj2= fitx(PS1+1:size(x,1));
genES=0; 
%% ================ define CMA-ES parameters ==============================
setting=[];fitness=[];bnd=[];
[setting,fitness,bnd]= init_cmaes_par(setting,fitness,bnd,EA_obj2,EA_2,n,PS2,Par.xmin,Par.xmax);

%% ===== prob. of each DE variant
probDE1=1./Par.n_opr .* ones(1,Par.n_opr);
%% ===================== archive data ====================================
arch_rate=1.4;
archive.NP = arch_rate * PS1; % the maximum size of the archive
archive.pop = zeros(0, n); % the solutions stored in te archive
archive.funvalues = zeros(0, 1); % the function value of the archived solutions
%% ==================== to adapt CR and F =================================
hist_pos=1;
memory_size=6;
pArchive.F=0.7*ones(memory_size,1);
pArchive.CR=0.5*ones(memory_size,1);
pArchive.freq=0.5*ones(memory_size,1);
pArchive.T= 0.1*ones(1,memory_size);

ArchiveF.flag1 = false;
ArchiveF.flag2 = false;

ArchiveF.goodF1all = [];
ArchiveF.goodF2all =[];
ArchiveF.badF1all = [];
ArchiveF.badF2all = [];
ArchiveF.goodF1 = [];
ArchiveF.goodF2 = [];
ArchiveF.badF1 = [];
ArchiveF.badF2 = [];
%%
InitPop=PS1;
cy=0;indx = 0; Probs=ones(1,2);

%% main loop
while current_eval<Par.Max_FES
    iter=iter+1;
    cy=cy+1; % to control CS
    %%
    ratio = current_eval / Par.Max_FES;
    %%  ================ determine the best MOEA ===========================
    if(cy==ceil(Par.CS+1))     
        %%calc normalized qualit -- NQual
        qual(1) = EA_obj1(1);qual(2) = EA_obj2(1);
        norm_qual = qual./sum(qual);
        norm_qual=1-norm_qual; %% to satisfy the bigger is the better

        %%Normalized diversity
        D(1) = mean(pdist2(EA_1(2:PS1,:),EA_1(1,:)));
        D(2) = mean(pdist2(EA_2(2:PS2,:),EA_2(1,:)));
        norm_div= D./sum(D);

        %%Total Imp
        Probs=norm_qual+norm_div;
        %%Update Prob_MODE and Prob_CMAES
        Probs = max(0.1, min(0.9,Probs./sum(Probs)));

        [~,indx]=max(Probs);
        if Probs(1)==Probs(2)
            indx=0;%% no sharing of information
        end        
    elseif cy==2*ceil(Par.CS)        
        %% share information
        if indx==1
            list_ind = randperm(PS1);
            list_ind= list_ind(1:(min(PS2,PS1)));
            EA_2(1:size(list_ind,2),:)= EA_1(list_ind,:);
            EA_obj2(1:size(list_ind,2))= EA_obj1(list_ind);
            [setting,fitness,bnd]= init_cmaes_par(setting,fitness,bnd,EA_obj2,EA_2, n, PS2, Par.xmin, Par.xmax);
            setting.sigma= setting.sigma*(1- (current_eval/Par.Max_FES));
        else
            if (min (EA_2(1,:)))> -100 && (max(EA_2(1,:)))<100 %% share best sol. in EA_2 if it is feasible
                EA_1(PS1,:)= EA_2(1,:);
                EA_obj1(PS1)= EA_obj2(1);
                [EA_obj1, ind]=sort(EA_obj1);
                EA_1=EA_1(ind,:);
            end
        end
        % reset cy and Probs
        cy=1;   Probs=ones(1,2);   
    end

    %% ====================== MOEA1 <-- SAMODE ============================
    if rand<Probs(1)
        genDE=genDE+1;
        %% apply MODE
        [EA_1,EA_obj1,probDE1,bestold,bestx,archive,hist_pos,memory_size,pArchive,ArchiveF,current_eval] = ...
        Improved_SHADE_cnEpSin(EA_1,EA_obj1,probDE1,bestold,bestx,archive,hist_pos,memory_size,pArchive,...
        Par.xmin,Par.xmax,n,genDE,ArchiveF,PS1,current_eval,I_fno,Par.Max_FES);
        %% =============================== NLR ===================================================
        
       %% Start: update by Youjian Guo 2022-06-24
        % From NL-SHADE-RSP equation (13)
        UpdPopSize = round((Par.MinPopSize - InitPop) * ratio^(1-ratio) + InitPop);
       %% End: update by Youjian Guo 2022-06-24
        
        if PS1 > UpdPopSize
            reduction_ind_num = PS1 - UpdPopSize;
            if PS1 - reduction_ind_num <  Par.MinPopSize
                reduction_ind_num = PS1 - Par.MinPopSize;
            end
            %% remove the worst ind.
            for r = 1 : reduction_ind_num
                vv=PS1;
                EA_1(vv,:)=[];
                EA_obj1(vv)=[];
                PS1 = PS1 - 1;
            end
            archive.NP = round(arch_rate * PS1);
            if size(archive.pop, 1) > archive.NP
                rndpos = randperm(size(archive.pop, 1));
                rndpos = rndpos(1 : archive.NP);
                archive.pop = archive.pop(rndpos, :);
                archive.funvalues=archive.funvalues(rndpos);
            end
        end          
    end

    %% ====================== MOEA2 <-- SAMO-ES ======================
    if rand<Probs(2)
        genES=genES+1;
        [ EA_2, EA_obj2, setting,bestold,bestx,bnd,fitness,current_eval] = ...
            SAMO_ES( EA_2, EA_obj2, setting, genES,bestold,bestx,fitness,bnd,...
            Par.xmin,Par.xmax,n,PS2,current_eval,I_fno,Par.Max_FES);
    end
    %% ============================ LS ====================================
    if ratio>=0.75
        if rand<Par.prob_ls
            [bestx,bestold,current_eval,succ] = LS2 (bestx,bestold,current_eval,I_fno,Par.Max_FES,Par.xmin,Par.xmax);
            if succ==1 %% if LS was successful
                EA_1(PS1,:)=bestx';
                EA_obj1(PS1)=bestold;
                [EA_obj1, sort_indx]=sort(EA_obj1);
                EA_1= EA_1(sort_indx,:);

                EA_2=repmat(EA_1(1,:), PS2, 1);
                [setting,fitness,bnd]= init_cmaes_par(setting,fitness,bnd,EA_obj2,EA_2,n,PS2,Par.xmin,Par.xmax);
                setting.sigma=1e-05;
                EA_obj2(1:PS2)= EA_obj1(1);
                Par.prob_ls=0.1;
            else
                Par.prob_ls=0.01; %% set p_LS to a small value it  LS was not successful
            end
        end
    end
    %% =============================== Print ==============================
    %fprintf('function\t %d iter\t %d current_eval\t %d fitness\t %.20f \n',I_fno,iter,current_eval,abs(Par.f_optimal-bestold));
end
fprintf('function\t %d,run\t %d, fitness\t %.16f,%d\n', I_fno,run, abs(Par.f_optimal-bestold),indx);
outcome= abs(Par.f_optimal-bestold);
end
