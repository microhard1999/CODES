function [x,fitx,prob,bestold,bestx,archive,hist_pos,memory_size,pArchive,ArchiveF,current_eval] = ...
    Improved_SHADE_cnEpSin(x,fitx,prob,bestold,bestx,archive,hist_pos,memory_size,pArchive,xmin,xmax,n,gen,ArchiveF,...
    PopSize,current_eval,I_fno,Max_FES)

ratio=current_eval/Max_FES;
pc=0.5;

mem_rand_index = ceil(memory_size * rand(1,PopSize));
mu_f = pArchive.F(mem_rand_index);
mu_cr = pArchive.CR(mem_rand_index);
mu_freq = pArchive.freq(mem_rand_index);
mu_T = pArchive.T(mem_rand_index);

%% Cr adaption
cr = normrnd(mu_cr,0.1);
cr = min(cr, 1);
cr = max(cr, 0);

%% Frequency adaption
freq= mu_freq + 0.1 * tan(pi*(rand(PopSize,1) - 0.5));
pos = find(freq <=0);
while ~ isempty(pos)
    freq(pos) = mu_freq(pos) + 0.1 * tan(pi * (rand(length(pos),1) - 0.5));
    pos = find(freq <= 0);
end
freq = min(freq, 1);

%% F adaption
F = mu_f + 0.1 * tan(pi * rand(PopSize,1)-0.5);
pos = find(F <= 0);
while ~ isempty(pos)
    F(pos) = mu_f(pos) + 0.1 * tan(pi * rand(length(pos),1)-0.5);
    pos = find(F <= 0);
end          

LP = 20;
ArchiveF.flag1 = false;
ArchiveF.flag2 = false;
if(ratio<=0.5)
    ArchiveF.flag1 = false;
    ArchiveF.flag2 = false;
    if (gen <= LP)
        c=rand;
        if(c < 0.5)
            F = 0.5 * (sin(2* pi * gen .* freq).* ratio + 1);
            ArchiveF.flag1 = true;
        else
            F = 0.5 * (sin(pi * gen + pi) * (1-ratio) +1) * ones(PopSize,1);
            ArchiveF.flag2 = true;
        end
    %==========================================================================
    else
        ns1_sum = 0;
        nf1_sum = 0;
        for hh = gen-LP : gen-1
            ns1_sum = ns1_sum + ArchiveF.goodF1all(1,hh);
            nf1_sum = nf1_sum + ArchiveF.badF1all(1,hh);
        end
        sumS1 = (ns1_sum/(ns1_sum + nf1_sum)) + 0.01;
        ns2_sum = 0;
        nf2_sum = 0;
        for hh = gen-LP : gen-1
            ns2_sum = ns2_sum + ArchiveF.goodF2all(1,hh);
            nf2_sum = nf2_sum + ArchiveF.badF2all(1,hh);
        end
        sumS2 = (ns2_sum/(ns2_sum + nf2_sum)) + 0.01;
        p1 = sumS1/(sumS1 + sumS2);
        p2 = sumS2/(sumS2 + sumS1);
        if(p1 > p2)
            F = 0.5 * (sin(2* pi * gen .* freq).* ratio + 1);
            ArchiveF.flag1 = true;
        else
            F = 0.5 * (sin(pi * gen + pi) * (1-ratio) +1)* ones(PopSize,1);
            ArchiveF.flag2 = true;
        end
    end
    %=======================================================================
end

%% Start: update by Youjian Guo 2022-06-24
% CR update, from EBOwithCMAR, equations (5) and (6).
T = normrnd(mu_T,0.1);
T = max(T,0)'; T = min(T,0.5)';
l = floor(n*rand(1,PopSize))+1;
CR = [];
if n == 1
    CR = cr;
else
    for i = 1:PopSize
        if rem(n,2) == 0
           mm = exp(-T(i)/n*(0:n/2-1));
           ll = cr(i).*[mm fliplr(mm)];
           CR(i,[l(i):n (1:l(i)-1)]) =ll;
        else
           mm = exp(-T(i)/n*(0:floor(n/2-1)));
           mm1 = exp(-T(i)/n*floor(n/2));
           ll = cr(i).*[mm mm1 fliplr(mm)];
           CR(i,[l(i):n (1:l(i)-1)]) =ll;
        end
    end
end
%% End: update by Youjian Guo 2022-06-24
%% ======================== generate new x =================================
popAll = [x;archive.pop]; %% set archive
%% Start: update by Youjian Guo 2022-06-24
% From NL-LSHADE-RSP equation (11).
r0 = 1 : PopSize;
[r1, r2, ~] = gnR1R2(PopSize, size(popAll, 1), r0);
pr= exp( -r0 ./ ( PopSize*ones(1,PopSize) ) );
pr= pr./sum(pr);
r3= randsrc( 1, PopSize, [r0;pr] );
pos = find((r3 == r0) | (r3 == r1) | (r3 == r2));
while ~ isempty(pos)
    r3(pos)= randsrc( 1, length(pos), [r0;pr] );
    pos = find((r3 == r0) | (r3 == r1) | (r3 == r2));
end
%% End: update by Youjian Guo 2022-06-24

%% Start: update by Youjian Guo 2022-06-24
% Mutation
% Using mutation for MODE in UMOEAsII, but only use equations (8) and (9), remove equation (10). 
vi=zeros(PopSize,n);
bb= rand(PopSize, 1);
probiter = prob(1,:);
op_1 = bb <=  probiter(1)*ones(PopSize, 1);
op_2 = bb > probiter(1)*ones(PopSize, 1);
pNP = max(round(0.1 * PopSize), 2); %% choose at least two best solutions
randindex = ceil(rand(1, PopSize) .* pNP); %% select from [1, 2, 3, ..., pNP]
randindex = max(1, randindex); %% to avoid the problem that rand = 0 and thus ceil(rand) = 0
phix = x(randindex, :); %% randomly choose one of the top 10% solutions
% DE2 -- current-to-pbest/archive
vi(op_1==1,:) = x(op_1==1,:)+ F(op_1==1, ones(1, n)) .*(phix(op_1==1,:) - x(op_1==1,:) + x(r1(op_1==1), :) - popAll(r2(op_1==1), :));
% DE2 --  current-to-pbest/without archive
vi(op_2==1,:) = x(op_2==1,:)+ F(op_2==1, ones(1, n)) .*(phix(op_2==1,:) - x(op_2==1,:) + x(r1(op_2==1), :) - x(r3(op_2==1), :));
% handle boundaries
vi = han_boun(vi,xmax,xmin,x,PopSize,1);
%% End: update by Youjian Guo 2022-06-24

%% crossover
J_= mod(floor(rand(PopSize, 1)*n), n) + 1;
J = (J_-1)*PopSize + (1:PopSize)';
crs = rand(PopSize, n) < CR;

if rand<pc
    niche = Species_Based(x,PopSize,0.5);
    SEL=size(niche,1); xmean=mean(niche);
    C =  1/(SEL-1)*(niche - xmean(ones(SEL,1), :))'*(niche - xmean(ones(SEL,1), :));
    C = triu(C) + transpose(triu(C,1)); % enforce symmetry
    [B,V] = eig(C);
    if max(diag(V)) > 1e20*min(diag(V))
        tmp = max(diag(V))/1e20 - min(diag(V));
        C = C + tmp*eye(n);
        [B, ~] = eig(C);
    end
    xt = x*B;
    vt = vi*B;
    ui = xt; ui(J)=vt(J); ui(crs)=vt(crs);
    ui = ui*B';
else
    ui = x;
    ui(J) = vi(J);
    ui(crs) = vi(crs);
end
            
%%evaluation
fitness_new=cec17_func(ui',I_fno);
for i=1:PopSize
    current_eval=current_eval+1;
    if fitness_new(i)<bestold
        bestold=fitness_new(i);
        bestx=ui(i,:);
    end      
end

%% calc. imprv. for Cr and F
diff = abs(fitx - fitness_new);
I =(fitness_new < fitx);
goodCR = cr(I == 1);
goodF = F(I == 1);
goodFreq = freq(I == 1);  
goodT= T(I==1)';

%% recored bad too
badF = F(I == 0);
%% ========================= update archive ===============================
archive = updateArchive(archive, x(I == 1, :), fitx(I == 1)');
%% ==================== update Prob. of each pf,pc ===========================
diff2 = max(0,(fitx - fitness_new))./abs(fitx);
count_S(1)=max(0,mean(diff2(op_1==1)));
count_S(2)=max(0,mean(diff2(op_2==1)));

%% update probs.
%%% Althouth count_S~=0 may slow down the convergence, it gives more
%%% diversity. In case you look for a better convergence you can set it to
%%% sum(count_S)~=0 
if count_S~=0 
prob= max(0.1,min(0.9,count_S./(sum(count_S))));
else
    prob=1/2 * ones(1,2);
end

%% Change F
if ArchiveF.flag1 == true
    ArchiveF.goodF1 = goodF;
    ArchiveF.goodF1all = [ArchiveF.goodF1all size(ArchiveF.goodF1,1)];

    ArchiveF.badF1 = badF;
    ArchiveF.badF1all = [ArchiveF.badF1all size(ArchiveF.badF1,1)];

    %% Add zero for other one  or add 1 to prevent the case of having NaN
    ArchiveF.goodF2all = [ArchiveF.goodF2all 1];
    ArchiveF.badF2all = [ArchiveF.badF2all 1];

end
if ArchiveF.flag2 == true
    ArchiveF.goodF2 = goodF;
    ArchiveF.goodF2all = [ArchiveF.goodF2all size(ArchiveF.goodF2,1)];

    ArchiveF.badF2 = badF;
    ArchiveF.badF2all = [ArchiveF.badF2all size(ArchiveF.badF2,1)];

    %% Add zero for other one
    ArchiveF.goodF1all = [ArchiveF.goodF1all 1];
    ArchiveF.badF1all = [ArchiveF.badF1all 1];
end
%% =================== update memory CR��F��freq =============================
num_success_params = numel(goodCR);
if num_success_params > 0
%     weightsDE = exp(diff(I==1))./sum(exp(diff(I==1)));% softmax Normalized exponential function
    weightsDE = diff(I == 1)./ sum(diff(I == 1));

    %%for updating the memory of scaling factor
    pArchive.F(hist_pos) = (weightsDE * (goodF .^ 2))./ (weightsDE * goodF);

    %%for updating the memory of crossover rate
    if max(goodCR) == 0 || pArchive.CR(hist_pos)  == -1
        pArchive.CR(hist_pos)  = -1;
    else
        pArchive.CR(hist_pos) = (weightsDE * (goodCR .^ 2)) / (weightsDE * goodCR);
    end
    
    %%for updating the memory of freq
    if max(goodFreq) == 0 || pArchive.freq(hist_pos)  == -1
       pArchive.freq(hist_pos)  = -1;
    else
       pArchive.freq(hist_pos) = (weightsDE * (goodFreq .^ 2)) / (weightsDE * goodFreq);
    end
    
    %%for updating the memory of T
    if sum(goodT)==0
        pArchive.T(hist_pos)=0;
    else
        pArchive.T(hist_pos) = (weightsDE * (goodT .^ 2)) ./ (weightsDE * goodT);
    end
    
    hist_pos= hist_pos+1;
    if hist_pos > memory_size;  hist_pos = 1; end
end

%%update x
x(I==1,:)=ui(I==1,:);
fitx(I==1)=fitness_new(I==1);

%sort
[fitx,index]=sort(fitx);
x=x(index,:);
