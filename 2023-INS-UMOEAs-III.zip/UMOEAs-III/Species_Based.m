function niche=Species_Based(x,NP,pcov)
dis=pdist2(x(1,:),x(1:NP,:));
[~,index]=sort(dis);
niche=x(index,:);
niche=niche(1:floor(NP*pcov),:);