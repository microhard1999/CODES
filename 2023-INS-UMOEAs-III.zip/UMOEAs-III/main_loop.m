clc
%%
outcome10D=zeros(51,30);
D=10;
for I_fno=1:30
    parfor run=1:51
        outcome10D(run,I_fno)=UMOEAsIII(run,I_fno,D);
    end
end
save('UMOEAsIII_10D.mat','outcome10D');
%%
outcome30D=zeros(51,30);
D=30;
for I_fno=1:30
    parfor run=1:51
        outcome30D(run,I_fno)=UMOEAsIII(run,I_fno,D);
    end
end
save('UMOEAsIII_30D.mat','outcome30D');
%%
outcome50D=zeros(51,30);
D=50;
for I_fno=1:30
    parfor run=1:51
        outcome50D(run,I_fno)=UMOEAsIII(run,I_fno,D);
    end
end
save('UMOEAsIII_50D.mat','outcome50D');
%%
outcome100D=zeros(51,30);
D=100;
for I_fno=1:30
    parfor run=1:51
        outcome100D(run,I_fno)=UMOEAsIII(run,I_fno,D);
    end
end
save('UMOEAsIII_100D.mat','outcome100D');