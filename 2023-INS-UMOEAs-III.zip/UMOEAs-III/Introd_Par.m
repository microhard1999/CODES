%% ============United Multi-Operator Evolutionary AlgorithmsII ============
% Should you have any queries, please contact
% Dr. Saber Elsayed. University of New South Wales at Canberra
% s.elsayed@adfa.edu.au
% www.saberelsayd.net or
% https://sites.google.com/site/saberelsayed3/home
% =========================================================================
function [Par] = Introd_Par(I_fno,n)

%% loading

Par.n_opr=2;  %% number of operators in MODE

if n==10
    Par.CS=50; %% cycle
    Par.Gmax = 2163;
elseif n==30
    Par.CS=100; %% cycle
    Par.Gmax = 2758;
elseif n==50
    Par.CS=100; %% cycle
    Par.Gmax = 3022;
else
    Par.CS=150; %% cycle
    Par.Gmax = 3401;
end
opt= 100:100:3000;       %% define the optimal solution as shown in the TR
Par.xmin= -100*ones(1,n);
Par.xmax= 100*ones(1,n);
Par.Max_FES=1e4*n;
Par.f_optimal=opt(I_fno);
Par.PopSize=18*n; %% population size
Par.MinPopSize=8;
Par.prob_ls=0.1;
end