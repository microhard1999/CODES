Journal: Information Sciences

Title:  A Variant of The United Multi-operator Evolutionary Algorithms Using Sequential Quadratic Programming and Improved SHADE-cnEpSin

DOI: https://doi.org/10.1016/j.ins.2022.11.131

This is a bug fix version. The F2 function in the original CEC2017 benchmark suite contained bugs. This version updates it to the latest version of CEC2017. Additionally, the boundary issue has been fixed.