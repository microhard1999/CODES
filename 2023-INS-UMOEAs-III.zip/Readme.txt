Journal: Information Sciences

Title:  A Variant of The United Multi-operator Evolutionary Algorithms Using Sequential Quadratic Programming and Improved SHADE-cnEpSin

Review link: https://www.sciencedirect.com/science/article/abs/pii/S0020025522014402?CMX_ID=&SIS_ID=&dgcid=STMJ_AUTH_SERV_PUBLISHED&utm_acid=139120793&utm_campaign=STMJ_AUTH_SERV_PUBLISHED&utm_in=DM322655&utm_medium=email&utm_source=AC_

DOI: https://doi.org/10.1016/j.ins.2022.11.131