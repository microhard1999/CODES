clear all;
rand('state',sum(100*clock));
randn('state',sum(100*clock));

% SSMSEP
%advfepSSMSEP()
% SSEP
%advfepSSEP();
% Cauchy
%fepGPDY(1);
% Gaussian
%fepGPDY(2);
% Levy12
%fepGPDY(3);
% Levy14
%fepGPDY(4);
% Levy16
%fepGPDY(5);
% Levy18
%fepGPDY(6);

%************************
% add by Libin Hong on 2013-02-15
% ��ͼ
%for no_gen = 1:100
%    x1(no_gen) = no_gen;
%end

y1 = load('TestingResults1.mat');
y2 = load('TestingResults2.mat');
y3 = load('TestingResults3.mat');
y4 = load('TestingResults4.mat');
y5 = load('TestingResults5.mat');
y6 = load('TestingResults6.mat');
y7 = load('TestingResults7.mat');
y8 = load('TestingResults8.mat');
y9 = load('TestingResults9.mat');
y10 = load('TestingResults10.mat');

plot(y1.epcauchy50, '-.', 'color', 'k'); %��-.��  %��ʾ��ɫ
hold on;
plot(y2.epgaussian50, '--', 'color', 'k');  %�㻮��  %��ʾ��ɫ
hold on;
plot(y3.levy12_50, '--', 'color', 'k','LineWidth',2);  %��  ��  %��ʾ��ɫ
hold on;
plot(y4.levy14_50, '-.', 'color', 'k','LineWidth',2);  %�㻮��  %��ʾ��ɫ
hold on;
plot(y5.levy16_50, ':', 'color', 'k','LineWidth',1);  %��  ��  %��ʾ��ɫ
hold on;
plot(y6.levy18_50, ':', 'color', 'k','LineWidth',2);  %��  ��  %��ʾ��ɫ
hold on;
plot(y7.gpdist50, '-', 'color', 'k');  %ʵ  ��  %��ʾ��ɫ
hold on;
plot(y8.gpdist50, '-', 'color', 'r');  %ʵ  ��  %��ʾ��ɫ
hold on;
plot(y9.gpdist50, '-', 'color', 'g');  %ʵ  ��  %��ʾ��ɫ
hold on;
plot(y10.gpdist50, '-', 'color', 'b');  %ʵ  ��  %��ʾ��ɫ

legend('Cauchy', 'Gaussian', '\alpha=1.2', '\alpha=1.4', '\alpha=1.6', '\alpha=1.8', 'SSEP', 'SSMSEP','SSMSEP-1','SSMSEP-2', 1);
legend('boxoff'); %����ʾ�߿�
set(gcf, 'color', 'w'); %ͼ����������Ϊ��ɫ
set(gca,'Yscale','log');

%set(gca,'xlim',[2900,3000]);
%set(gca,'ylim',[0.1,0.5]);

titleinfo={[''];['Evolutionary Process of Function 10 Over 50 Runs'];['']};
%titleinfo=strcat('Function Instance of Function Class1 with a=',num2str(a(1)),',b=',num2str(b(1)),',c=',num2str(c(1)));
%titleinfo=strcat('Function Instance of Function Class2 with a=',num2str(a(1)),',b=',num2str(b(1)));
title(titleinfo,'fontsize',10);
xlabel('Generation'); 
ylabel('Averaged fitness value over 50 runs');
%************************