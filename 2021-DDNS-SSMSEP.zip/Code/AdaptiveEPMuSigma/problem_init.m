function problem_init(n,v)
% Initialize the n-th problem parameters.

global PROB_VECTOR
global PROB_XU
global PROB_XL

switch n
    case {1}
		if (nargin<2) PROB_VECTOR = 30; else PROB_VECTOR = v; end
		PROB_XU(1:PROB_VECTOR) =  100;
		PROB_XL(1:PROB_VECTOR) = -100;
    case {2}
		if (nargin<2) PROB_VECTOR = 30; else PROB_VECTOR = v; end
		PROB_XU(1:PROB_VECTOR) =  10;
		PROB_XL(1:PROB_VECTOR) = -10;
    case {3}
		if (nargin<2) PROB_VECTOR = 30; else PROB_VECTOR = v; end
		PROB_XU(1:PROB_VECTOR) =  100;
		PROB_XL(1:PROB_VECTOR) = -100;
    case {4}
		if (nargin<2) PROB_VECTOR = 30; else PROB_VECTOR = v; end
		PROB_XU(1:PROB_VECTOR) =  100;
		PROB_XL(1:PROB_VECTOR) = -100;
	case {5}
		if (nargin<2) PROB_VECTOR = 30; else PROB_VECTOR = v; end
		PROB_XU(1:PROB_VECTOR) =  30;
		PROB_XL(1:PROB_VECTOR) = -30;
	case {6}
		if (nargin<2) PROB_VECTOR = 30; else PROB_VECTOR = v; end
		PROB_XU(1:PROB_VECTOR) =  100;
		PROB_XL(1:PROB_VECTOR) = -100;
    case {7}
		if (nargin<2) PROB_VECTOR = 30; else PROB_VECTOR = v; end
		PROB_XU(1:PROB_VECTOR) =  1.28;
		PROB_XL(1:PROB_VECTOR) = -1.28;  
    case {8}
		if (nargin<2) PROB_VECTOR = 30; else PROB_VECTOR = v; end
		PROB_XU(1:PROB_VECTOR) =  500;
		PROB_XL(1:PROB_VECTOR) = -500;
	case {9}
		if (nargin<2) PROB_VECTOR = 30; else PROB_VECTOR = v; end
		PROB_XU(1:PROB_VECTOR) =  5.12;
		PROB_XL(1:PROB_VECTOR) = -5.12;
	case {10}
		if (nargin<2) PROB_VECTOR = 30; else PROB_VECTOR = v; end
		PROB_XU(1:PROB_VECTOR) =  32;
		PROB_XL(1:PROB_VECTOR) = -32;
	case {11}
		if (nargin<2) PROB_VECTOR = 30; else PROB_VECTOR = v; end
		PROB_XU(1:PROB_VECTOR) =  600;
		PROB_XL(1:PROB_VECTOR) = -600;
	case {12}
		if (nargin<2) PROB_VECTOR = 30; else PROB_VECTOR = v; end
		PROB_XU(1:PROB_VECTOR) =  50;
		PROB_XL(1:PROB_VECTOR) = -50;
	case {13}
		if (nargin<2) PROB_VECTOR = 30; else PROB_VECTOR = v; end
		PROB_XU(1:PROB_VECTOR) =  50;
		PROB_XL(1:PROB_VECTOR) = -50;
	case {14}
		PROB_VECTOR = 2;
		PROB_XU(1:PROB_VECTOR) =  65.536;
		PROB_XL(1:PROB_VECTOR) = -65.536;
	case {15}
		PROB_VECTOR = 4;
		PROB_XU(1:PROB_VECTOR) =  5;
		PROB_XL(1:PROB_VECTOR) = -5;
	case {16}
		PROB_VECTOR = 2;
		PROB_XU(1:PROB_VECTOR) =  5;
		PROB_XL(1:PROB_VECTOR) = -5;
	case {17}
		PROB_VECTOR = 2;
		PROB_XU(1) =  10;
		PROB_XL(1) =  -5;
		PROB_XU(2) =  15;
		PROB_XL(2) =   0;
	case {18}
		PROB_VECTOR = 2;
		PROB_XU(1:PROB_VECTOR) =  2;
		PROB_XL(1:PROB_VECTOR) = -2;
	case {19}
		PROB_VECTOR = 3;
		PROB_XU(1:PROB_VECTOR) =   1;
		PROB_XL(1:PROB_VECTOR) =   0;
	case {20}
		PROB_VECTOR = 6;
		PROB_XU(1:PROB_VECTOR) =   1;
		PROB_XL(1:PROB_VECTOR) =   0;
	case {21}
		PROB_VECTOR = 4;
		PROB_XU(1:PROB_VECTOR) =  10;
		PROB_XL(1:PROB_VECTOR) =   0;
	case {22}
		PROB_VECTOR = 4;
		PROB_XU(1:PROB_VECTOR) =  10;
		PROB_XL(1:PROB_VECTOR) =   0;
	case {23}
		PROB_VECTOR = 4;
		PROB_XU(1:PROB_VECTOR) =  10;
		PROB_XL(1:PROB_VECTOR) =   0;
	case {24}
		PROB_VECTOR = 2;
		PROB_XU(1:PROB_VECTOR) =  100;
		PROB_XL(1:PROB_VECTOR) = -100;
	case {25}
		PROB_VECTOR = 2;
		PROB_XU(1:PROB_VECTOR) =  100;
		PROB_XL(1:PROB_VECTOR) = -100;
	case {26}
		if (nargin<2) PROB_VECTOR = 30; else PROB_VECTOR = v; end
		PROB_XU(1:PROB_VECTOR) =  pi;
		PROB_XL(1:PROB_VECTOR) = -pi;
	case {27}
		if (nargin<2) PROB_VECTOR = 30; else PROB_VECTOR = v; end
		PROB_XU(1:PROB_VECTOR) =  10;
		PROB_XL(1:PROB_VECTOR) =   0;
	case {101}
		PROB_VECTOR = 2;
		PROB_XU(1:PROB_VECTOR) =  10;
		PROB_XL(1:PROB_VECTOR) = -10;
	case {102}
		PROB_VECTOR = 10;
		PROB_XU(1:PROB_VECTOR) =  10;
		PROB_XL(1:PROB_VECTOR) = -10;
	otherwise
		PROB_VECTOR = 2;
		PROB_XU(1:PROB_VECTOR) =  10;
		PROB_XL(1:PROB_VECTOR) = -10;
end
