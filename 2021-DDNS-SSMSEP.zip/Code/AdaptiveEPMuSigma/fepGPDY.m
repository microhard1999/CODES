function fepGPDY(type)

%clear all;
rand('state',sum(100*clock));
randn('state',sum(100*clock));
normrnd('state',sum(100*clock));

global PROB_VECTOR;
global PROB_XU;
global PROB_XL;

PROBLEM_NO     =    10;
problem_init(PROBLEM_NO,30);

ITERATION = 50;
% Population size
POP_NO    = 100;
MAX_GENERATION = 15;
% Tournament size
TOURNAMENT_SIZE= 10;

lower_bound = 1e-3;
tau  = 1/sqrt(2*sqrt(PROB_VECTOR));
tau1 = 1/sqrt(2*PROB_VECTOR);

for no_run = 1:ITERATION % perform idx independent runs

    % Initial standard deviations 3.0
    pnteta = repmat(3, POP_NO, PROB_VECTOR);
    for i = 1:POP_NO
        pntx(i,:) = rand(1,PROB_VECTOR).*(PROB_XU-PROB_XL) + PROB_XL; 
        pntf(i)   = fitness(PROBLEM_NO,pntx(i,:));
    end
    
    for idx = 1:MAX_GENERATION

        % Mutation and evaluation
        for kk = 1:POP_NO
            a_normal = randn(1);
            pnteta(POP_NO+kk,:) = pnteta(kk,:).*exp(tau1*a_normal+tau*randn(1,PROB_VECTOR));
            for i = 1:PROB_VECTOR     
                %if pnteta(POP_NO+kk,i) > lower_bound
                if pnteta(POP_NO+kk,i) < lower_bound
                    pnteta(POP_NO+kk,i) = lower_bound;
                end
            end
            if type==1
                % Cauchy distribution
                pntx(POP_NO+kk,:) = pntx(kk,:) + pnteta(POP_NO+kk,:).*cauchy(1,PROB_VECTOR);
            end
            if type==2
                % Gaussian distribution
                pntx(POP_NO+kk,:) = pntx(kk,:) + pnteta(POP_NO+kk,:).*randn(1,PROB_VECTOR);
            end
            if type==3
                pntx(POP_NO+kk,:) = pntx(kk,:) + pnteta(POP_NO+kk,:).*levyrand12(1,PROB_VECTOR);
            end
            if type==4
                pntx(POP_NO+kk,:) = pntx(kk,:) + pnteta(POP_NO+kk,:).*levyrand14(1,PROB_VECTOR);
            end
            if type==5
                pntx(POP_NO+kk,:) = pntx(kk,:) + pnteta(POP_NO+kk,:).*levyrand16(1,PROB_VECTOR);
            end
            if type==6
                pntx(POP_NO+kk,:) = pntx(kk,:) + pnteta(POP_NO+kk,:).*levyrand18(1,PROB_VECTOR);
            end
       
            
            %for i = 1:PROB_VECTOR               
            %    if pntx(POP_NO+kk,:) > PROB_XU
            %        pntx(POP_NO+kk,:) = PROB_XU(i);
            %    end
            %    if pntx(POP_NO+kk,:) < PROB_XL
            %        pntx(POP_NO+kk,:) = PROB_XL(i);
            %    end
            %end
            
            % for f8
            for i = 1:PROB_VECTOR               
                if pntx(POP_NO+kk,i) > PROB_XU
                    pntx(POP_NO+kk,i) = PROB_XU(i);
                end
                if pntx(POP_NO+kk,i) < PROB_XL
                    pntx(POP_NO+kk,i) = PROB_XL(i);
                end
            end
            pntf(POP_NO+kk) = fitness(PROBLEM_NO,pntx(POP_NO+kk,:));
        end
        
        % Tourament selection
        for kk = 1:POP_NO*2
            win(kk) = 0;
            for i = 1:TOURNAMENT_SIZE
                win(kk) = win(kk) - (pntf(kk) < pntf(ceil(rand(1)*POP_NO*2)));
            end
        end      
        
        sort_chd = sortrows([pntx,pntf',pnteta,win'],PROB_VECTOR*2+2);
        pntx  = sort_chd(1:POP_NO,1:PROB_VECTOR);
        pntf  = sort_chd(1:POP_NO,PROB_VECTOR+1)';
        pnteta= sort_chd(1:POP_NO,PROB_VECTOR+2:PROB_VECTOR*2+1);
        win   = sort_chd(1:POP_NO,PROB_VECTOR*2+2)';
       
        %************************
        % add by Libin Hong on 2013-02-15
        %disp(strcat(num2str(idx),',',num2str(pntf(1)),',',num2str(mean(pntf))));
        if type==1
            epcauchy(no_run,idx) = pntf(1);
        end
        if type==2
            epgaussian(no_run,idx) = pntf(1);
        end
        if type==3
           levy12(no_run,idx) = pntf(1);
        end
        if type==4
           levy14(no_run,idx) = pntf(1);
        end
        if type==5
           levy16(no_run,idx) = pntf(1);
        end
        if type==6
           levy18(no_run,idx) = pntf(1);
        end
%         if type==7
%            gpdist(no_run,idx) = pntf(1);
%         end
        %************************
    end 
    
    disp(strcat(num2str(idx),',',num2str(pntf(1)),',',num2str(mean(pntf),'%.12f')));
    
    %all_min(no_run) = pntf(1);
    %all_mean(no_run)= mean(pntf);
end
%************************
% calculate each avg value of each generation over 50 runs
% add by Libin Hong on 2013-02-15
if type==1
    % calculate avg value of each column
    for j = 1:MAX_GENERATION
        n = 0;
        for i = 1:ITERATION
            n = n + epcauchy(i,j);
        end
        epcauchy50(j) = n/ITERATION;    
    end
    save('TestingResults1.mat', 'epcauchy50');
end
if type==2
    % calculate avg value of each column
    for j = 1:MAX_GENERATION
        n = 0;
        for i = 1:ITERATION
            n = n + epgaussian(i,j);
        end
        epgaussian50(j) = n/ITERATION;    
    end
    save('TestingResults2.mat', 'epgaussian50');
end
if type==3
    % calculate avg value of each column
    for j = 1:MAX_GENERATION
        n = 0;
        for i = 1:ITERATION
            n = n + levy12(i,j);
        end
        levy12_50(j) = n/ITERATION;    
    end
    save('TestingResults3.mat', 'levy12_50');
end
if type==4
    % calculate avg value of each column
    for j = 1:MAX_GENERATION
        n = 0;
        for i = 1:ITERATION
            n = n + levy14(i,j);
        end
        levy14_50(j) = n/ITERATION;    
    end
    save('TestingResults4.mat', 'levy14_50');
end
if type==5
    % calculate avg value of each column
    for j = 1:MAX_GENERATION
        n = 0;
        for i = 1:ITERATION
            n = n + levy16(i,j);
        end
        levy16_50(j) = n/ITERATION;    
    end
    save('TestingResults5.mat', 'levy16_50');
end
if type==6
    % calculate avg value of each column
    for j = 1:MAX_GENERATION
        n = 0;
        for i = 1:ITERATION
            n = n + levy18(i,j);
        end
        levy18_50(j) = n/ITERATION;    
    end
    save('TestingResults6.mat', 'levy18_50');
end
% if type==7
%     % calculate avg value of each column
%     for j = 1:MAX_GENERATION
%         n = 0;
%         for i = 1:ITERATION
%             n = n + gpdist(i,j);
%         end
%         gpdist50(j) = n/ITERATION;    
%     end
%     save('TestingResults7.mat', 'gpdist50');
% end
%************************
disp(strcat('Completed!'));



