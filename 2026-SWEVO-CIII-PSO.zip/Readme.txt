Swarm and Evolutionary Computation
Paper title: Particle Swarm Optimization with Complementary Velocity Learning Scheme and Multiple Performance Mechanisms: Applications in Power Electronics
https://doi.org/10.1016/j.swevo.2026.102410
First and corresponding author: Libin Hong (Libin.Hong@hznu.edu.cn)