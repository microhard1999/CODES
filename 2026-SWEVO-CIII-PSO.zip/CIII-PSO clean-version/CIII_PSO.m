function [Gbest_val]= CIII_PSO(fhd,MaxFES,N,D,LB,UB,prbs)
% Gbest_val: global best position's fitness
% Pbest_val: personal best position's fitness
% LB/UP: lower/upper search boundry
% pos: position
% inw: inertia weight

rand('state',sum(100*clock));

%% Initialize pos and velocity
velocityelocity_max=(UB-LB)/4;
velocityelocity_min=-velocityelocity_max;
pos=rand(N,D).*(UB-LB)+LB;
velocity=rand(N,D).*(velocityelocity_max-velocityelocity_min)+velocityelocity_min;
fitness=zeros(N,1);

%% Initialize Pbest and Gbest
for i=1:N
    fitness(i)=feval(fhd,pos(i,:)',prbs);
end
fitcount=N;
[~,index]=sort(fitness);
Gbest=pos(index(1),:);
Gbest_val=fitness(index(1));
Pbest=pos;
Pbest_val=fitness;
farpos=[];
farval=[];
farnum=0.3*N;
fcount=0;
rr1=rand(N,1);

count=zeros(1,N);
K2=0.1;
pro_ls=0.1;
flag=0;
selection_num=round(60 + 20./(1 + exp(-0.3*(D - 75))));
elitemax=ceil(10/pi * atan(0.5*(D-20)) + 14.7898);

nSold=0;
S_F = zeros(1,N);
S_df = zeros(1,N);
MF=mean(rr1);

%% main loop
while fitcount<=MaxFES
    
    inw=0.9-0.5*(fitcount/MaxFES);
    c=1.5-0.5*(fitcount/MaxFES);
    c1=1-0.5*(fitcount/MaxFES);
    pl=0.9-0.2*(fitcount/MaxFES);
    
    elite_num=ceil(elitemax-fitcount/MaxFES*K2*N);
    
    [~,index_f] = sort(fitness);
    pos = pos(index_f,:);
    velocity = velocity(index_f,:);
    fitness = fitness(index_f);
    Pbest = Pbest(index_f,:);
    Pbest_val = Pbest_val(index_f);
    count = count(index_f);
    
    %% from CELDE Storage Control Coefficient
    
    for i = 1:N
        while rr1(i) <= 0
            rr1(i) = MF + 0.1 * tan(pi * (rand - 0.5)); 
        end
    end
    rr1(rr1>1)=MF;
    
    %% New archive, storing particles far from Gbest
    [farpos,farval,fcount] = far(Pbest_val,Pbest,Gbest,N,farnum,fcount,farpos,farval,count);
    
    %% Inspire from SL-PSO, SL-PSO uses pos, here we use Pbest
    labelarc=randi(N,N,D);
    
    p_arc=zeros(N,D);
    for j = 1:D
        p_arc(:,j) = Pbest(labelarc(:,j),j);
    end
    
    pos_old=pos;
    nS=0;
    
    for i=1:N
        
        fu=ceil(length(farval)*rand);
        
        if (nSold/N)<rand
            f=rr1(i);f2=rr1(i);userr1=1;
        else
            f=rand;f2=rand;userr1=0;
        end
        
        if i>elite_num
            %% In the middle
            velocity(i,:)=inw.*velocity(i,:)+f.*(Pbest(randperm(i,1),:)-pos(i,:))+c1*f2.*(Pbest(randperm(elite_num,1),:)-pos(i,:));
        else
            if pl>rand
                %% excel global search
                velocity(i,:)=rand(1,D).*(p_arc(i,:)-pos(i,:))+c*rand(1,D).*(farpos(fu,:)-pos(i,:));
            else
                %% excel local search
                velocity(i,:)=inw.*velocity(i,:)+rand(1,D).*(pos(i,:)-p_arc(i,:))+f.*(Gbest(1,:)-pos(i,:));
            end
        end
        
        velocity(i,velocity(i,:)>velocityelocity_max) = rand*(velocityelocity_max-velocityelocity_min)+velocityelocity_min;
        velocity(i,velocity(i,:)<velocityelocity_min) = rand*(velocityelocity_max-velocityelocity_min)+velocityelocity_min;
        pos(i,:) = pos(i,:) + velocity(i,:);
        %% boundary processing function
        for k=1:D
            if pos(i,k)>UB || pos(i,k)<LB
                pos(i,k)=pos_old(i,k);
            end
        end
        fitness(i)=feval(fhd,pos(i,:)',prbs);
        fitcount=fitcount+1;
        
        if fitness(i)>=Pbest_val(i)
            count(i) = count(i)+1;
            rr1(i)=(userr1==0)*rr1(i)+(userr1==1)*0;
        else
            if userr1==1
                nS=nS+1;
                S_F(nS)=rr1(i);
                S_df(nS)=abs(fitness(i)-Pbest_val(i));
            end
            count(i)=0;
        end
        
        Pbest(i,:)=(fitness(i)<Pbest_val(i))*pos(i,:)+(fitness(i)>=Pbest_val(i))*Pbest(i,:);
        Pbest_val(i)=(fitness(i)<Pbest_val(i))*fitness(i)+(fitness(i)>=Pbest_val(i))*Pbest_val(i);
        Gbest=(fitness(i)<Gbest_val)*pos(i,:)+(fitness(i)>=Gbest_val)*Gbest;
        Gbest_val=(fitness(i)<Gbest_val)*fitness(i)+(fitness(i)>=Gbest_val)*Gbest_val;

        if fitcount>=MaxFES
            break;
        end
    end
    
    if fitcount>=MaxFES
        break;
    end
        
%% apply interior-point
    temp=[];temp2=[];
    for i=1:N
        distance(i,1) = norm(pos(i,:)-Gbest);
    end
    [~,index]=sort(distance);
    for i = 1:N
        if count(index(i)) == 0
            temp = pos(index(i),:);
        end
    end
    if isempty(temp)
        temp=Gbest;
    end
    
    for i = N:-1:1
        if count(i) == 0
            temp2 = Pbest(i,:);
        end
    end
    if isempty(temp2)
        temp2=Gbest;
    end
    
    if ((fitcount>0.75*MaxFES && pro_ls>rand) || (fitcount>0.1*MaxFES && flag==0)) && (MaxFES-fitcount)>0.021*MaxFES
        
        xmin = -100*ones(1,D);
        xmax = 100*ones(1,D);
        
        [newGbest,newGbest_val,fitcount,succ] = LS2 (temp2,Gbest_val,fitcount,prbs,xmin,xmax,MaxFES);
        
        if succ==1
            Gbest = newGbest'; Gbest_val = newGbest_val;
        else
            if fitcount>=MaxFES
                break;
            end
            
            if fitcount>0.75*MaxFES
                pro_ls=0.01;
            else
                pro_ls=0.1;
            end
            
            if (isequal(temp,temp2))==0 && (MaxFES-fitcount)>0.021*MaxFES
                [newGbest,newGbest_val,fitcount,succ1] = LS2 (temp,Gbest_val,fitcount,prbs,xmin,xmax,MaxFES);
                
                if succ1==1
                    Gbest = newGbest'; Gbest_val = newGbest_val;
                end
            end
        end
        
        flag=1;
        
    end
    
    if fitcount>=MaxFES
        break;
    end
    
    if nS > 0 
        w = S_df(1:nS)./sum(S_df(1:nS));
        MF = sum(w.*S_F(1:nS));
    end
%% apply EDA
    nSold=nS;
    if (nS/N)<rand
        r1=randperm(N,selection_num);
        selection_pos = Pbest(r1,:);
        mu = mean(selection_pos, 1);
        SEL=size(r1,2);
        mu_matrix=repmat(mu,SEL,1);
        temp_C=selection_pos-mu_matrix;
        for i=1:selection_num
            for k=1:D
                if temp_C(i,k)>UB || temp_C(i,k)<LB
                    temp_C(i,k)=selection_pos(i,k);
                end
            end
        end
        C_matrix =(temp_C'*temp_C)/(SEL-1);
        C_matrix = C_matrix + 1e-6 * eye(D);  % 基本正则化
        C_matrix = triu(C_matrix) + transpose(triu(C_matrix,1));

        temp_pos = mvnrnd(mu,C_matrix,elite_num);

        fuE=[];
        for i=1:elite_num
            for k=1:D
                if temp_pos(i,k)>UB || temp_pos(i,k)<LB
                    temp_pos(i,k)=rand*(UB-LB)+LB;
                end
            end

            fuE(i,1)=feval(fhd,temp_pos(i,:)',prbs);
            fitcount=fitcount+1;
            
            if fitcount>=MaxFES
                break;
            end

            Gbest=(fuE(i)<Gbest_val)*temp_pos(i,:)+(fuE(i)>=Gbest_val)*Gbest;
            Gbest_val=(fuE(i)<Gbest_val)*fuE(i)+(fuE(i)>=Gbest_val)*Gbest_val;
        end
        [~,index_f] = sort(fitness);
        pos = pos(index_f,:);
        velocity = velocity(index_f,:);
        fitness = fitness(index_f);
        Pbest = Pbest(index_f,:);
        Pbest_val = Pbest_val(index_f);
        count = count(index_f);

        pos(N-size(fuE,1)+1:N,:)=temp_pos(1:size(fuE,1),:);
        fitness(N-size(fuE,1)+1:N)=fuE;
        Pbest(N-size(fuE,1)+1:N,:)=temp_pos(1:size(fuE,1),:);
        Pbest_val(N-size(fuE,1)+1:N)=fuE;
        count(N-size(fuE,1)+1:N)=0;
    end

    if fitcount>=MaxFES
        break;
    end
end

end