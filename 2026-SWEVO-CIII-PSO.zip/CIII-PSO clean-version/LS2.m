function [newGbest,newGbest_val,current_eval,succ] = LS2 (Gbest,Gbest_val,fitcount,prbs,xmin,xmax,MaxFES)

Par.LS_FE=0.02*MaxFES; %% Max FFEs_LS

options=optimset('Display','off','algorithm','interior-point','UseParallel','never','MaxFunEvals',Par.LS_FE) ;

[Xsqp, FUN , ~ , details]=fmincon(@cec17_func,Gbest',[],[],[],[],xmin,xmax,[],options,prbs);

%% check if there is an improvement in the fitness value and update P_{ls}
if (Gbest_val-FUN)>0
    
    succ=1;
    newGbest_val = FUN;
    newGbest=Xsqp;
  
    
else
    succ=0;
    newGbest_val=Gbest_val;
    newGbest=Gbest;
   
end
%% update FFEs
current_eval=fitcount+details.funcCount;

end


