clear
clc

%% introductory Definitions
num_prbs = 30;                      %% number of test problems
runs=51;                        %% number of runs

LB = -100;
UB = 100;

fhd=str2func('cec17_func');

RecordFEsFactor = 0.001:0.001:1;
progress = numel(RecordFEsFactor);

N = 100;
for D = [100]
    MaxFES = 10000 * D;
    for i = 30
        prbs = i;
        allerrorvals = zeros(progress,runs);
        for j = 1:51
            
            [Gbest_val]= CIII_PSO(fhd,MaxFES,N,D,LB,UB,prbs);
            
        end
    end
end
