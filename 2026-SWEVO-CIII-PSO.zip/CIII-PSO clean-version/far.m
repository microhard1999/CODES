function [farpos,farval,fcount] = far(fitness,pos,Gbest,N,selection_num,fcount,farpos,farval,count)

for i=1:N
    distance(i,1) = norm(pos(i,:)-Gbest);
end

[~,index]=sort(distance,'descend');

for i=1:selection_num
    if count(index(i))<3
        %% Code source EAPSO
        fcount=fcount+1;
        if fcount<=N
            farpos(fcount,:)=pos(index(i),:);
            farval(fcount,1)=fitness(index(i));
        else
            a=randperm(N,1);
            b=randperm(N,1);
            while a==b
                a=randperm(N,1);
                b=randperm(N,1);
            end
            if farval(a,:)<farval(b,:)
                if fitness(index(i))<farval(b)
                    farval(b)=fitness(index(i));
                    farpos(b,:)=pos(index(i),:);
                end
            else
                if fitness(index(i))<farval(a)
                    farval(a)=fitness(index(i));
                    farpos(a,:)=pos(index(i),:);
                end
            end
        end
    end
end

end