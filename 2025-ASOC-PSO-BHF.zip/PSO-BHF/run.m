clc;
clear all;
fhd = 'cec17_func';

Particle_Number=40;
Max_Gen=2500;


VRmin = -100;
VRmax = 100;
varargin = 1;
func_cnt = 30;
runs=51;
RecordFEsFactor = 0.001:0.001:1;
progress = numel(RecordFEsFactor);
for D = [10 30 50 100]
    maxfits = 10000*D;
    Max_Gen = floor(maxfits/Particle_Number);
    for i=1:func_cnt % ww  problem 
        fprintf('Problem =\t %d\n',i);
        allerrorvals = zeros(progress, runs);
        for j=1:runs  % ww runs
            func_num=i;
            fprintf('run =\t %d\n',j);
            [Gbest_val,everyfit]= PSO_BHF(fhd,maxfits,Particle_Number,D,VRmin,VRmax,i);
            errorfit = everyfit(floor(RecordFEsFactor*size(everyfit,2)));
            allerrorvals(:, j) = errorfit';
        end
        file_name=sprintf('plot\\PSO-BHF_%s_%s.txt',int2str(i),int2str(D));
        save(file_name, 'allerrorvals', '-ascii');       
    end
end


