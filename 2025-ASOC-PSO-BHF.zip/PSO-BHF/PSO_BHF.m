function [Gbest_val,everyfit]= PSO_BHF(fhd,MaxFES,N,Dim,LB,UB,fun_num)
rand('state',sum(100*clock));
xmin= -100*ones(1,Dim);
xmax= 100*ones(1,Dim);
everyfit=zeros(1,MaxFES);
Maxiter=ceil(MaxFES/N);
velocityelocity_max=(UB-LB)/4;
velocityelocity_min=-velocityelocity_max;
pos=rand(N,Dim).*(UB-LB)+LB;
velocity=rand(N,Dim).*(velocityelocity_max-velocityelocity_min)+velocityelocity_min;
fitness=zeros(N,1);
for i=1:N
    fitness(i)=feval(fhd,pos(i,:)',fun_num);
end
fitcount=N;
everyfit(1:fitcount)=min(fitness);
[min_val,min_index]=min(fitness);
Gbest=pos(min_index,:);
Gbest_val=min_val;
Pbest=pos;
Pbest_val=fitness;
count=zeros(1,N);
c=1.49445;
iter=1;
K1=0.5;
K2=0.4;
G=7;

problem_size = Dim;
pop_size = N;

%% Initialize CMAES parameters
sigma = 0.5;          % coordinate wise standard deviation (step size)
xmean = rand(problem_size,1);    % objective variables initial point
mu = pop_size/2;               % number of parents/points for recombination
weights = log(mu+1/2)-log(1:mu)'; % muXone array for weighted recombination
mu = floor(mu);
weights = weights/sum(weights);     % normalize recombination weights array
mueff=sum(weights)^2/sum(weights.^2); % variance-effectiveness of sum w_i x_i

% Strategy parameter setting: Adaptation
cc = (4 + mueff/problem_size) / (problem_size+4 + 2*mueff/problem_size); % time constant for cumulation for C
cs = (mueff+2) / (problem_size+mueff+5);  % t-const for cumulation for sigma control
c1 = 2 / ((problem_size+1.3)^2+mueff);    % learning rate for rank-one update of C
cmu = min(1-c1, 2 * (mueff-2+1/mueff) / ((problem_size+2)^2+mueff));  % and for rank-mu update
damps = 1 + 2*max(0, sqrt((mueff-1)/(problem_size+1))-1) + cs; % damping for sigma usually close to 1

% Initialize dynamic (internal) strategy parameters and constants
pc = zeros(problem_size,1);
ps = zeros(problem_size,1);   % evolution paths for C and sigma
B = eye(problem_size,problem_size);                       % B defines the coordinate system
D = ones(problem_size,1);                      % diagonal D defines the scaling
C = B * diag(D.^2) * B';            % covariance matrix C
invsqrtC = B * diag(D.^-1) * B';    % C^-1/2
eigeneval = 0;                      % track update of B and D
chiN=problem_size^0.5*(1-1/(4*problem_size)+1/(21*problem_size^2));  % expectation of

Hybridization_flag=1; % Indicator flag if we need to Activate CMAES Hybridization

Probs = [0.5 0.5];

a=1.5;
best_stop = 0;
K= 50 ;
first_solution_position_f = Gbest_val;
second_solution_position_f=Gbest_val;
third_solution_position_f=Gbest_val;
first_solution_position =Gbest;
second_solution_position=Gbest;
third_solution_position=Gbest;
while fitcount<=MaxFES
    best_improved = 0;
    inw=0.9-0.5*(iter/Maxiter);
    iter=iter+1;
    elite_num=ceil(N*K1-iter/Maxiter*(K1-K2)*N);
    [~,index]=sort(fitness);
    allFitness=[fitness;first_solution_position_f;second_solution_position_f;third_solution_position_f];
    allPos = [pos;first_solution_position;second_solution_position;third_solution_position];
    [~,allindex]=sort(allFitness);
    j = allindex(1:3);
    first_solution_position = allPos(j(1),:);
    second_solution_position=allPos(j(2),:);
    third_solution_position=allPos(j(3),:);
    first_solution_position_f = allFitness(j(1),:);
    second_solution_position_f=allFitness(j(2),:);
    third_solution_position_f=allFitness(j(3),:);
    OO=zeros(1,Dim);
    for i=1:elite_num
        if fitness(index(i))>0
            f(i)=1/(fitness(index(i))+1);
        else
            f(i)=1+abs(fitness(index(i)));
        end
    end

    elite=zeros(1,elite_num);
    elite(1:elite_num)=index(1:elite_num);
    ordinary=zeros(1,N-elite_num);
    ordinary(1:N-elite_num)=index(elite_num+1:N);

    for i=1:elite_num
        OO=OO+f(i)/sum(f)*Pbest(index(i),:);
    end
    
    

    fitold=fitness;
    mem_rand_ratio = rand(N, 1);%%ww
    Class_Select_Index=(mem_rand_ratio<=Probs(1));
    
    
    for i=1:N
        ranknum=index(i);
        if ranknum<=elite_num
            velocity(i,:)=inw.*velocity(i,:)+c*rand(1,Dim).*(Pbest(i,:)-pos(i,:));
            velocity(i,velocity(i,:)>velocityelocity_max) = velocityelocity_max;
            velocity(i,velocity(i,:)<velocityelocity_min) = velocityelocity_min;
            pos(i,:) = pos(i,:) + velocity(i,:);
        elseif(~Class_Select_Index(i)&&Hybridization_flag)
            temp = xmean + sigma * B * (D .* randn(problem_size,1)); % m + sig * Normal(0,C)
            if(~isreal(temp)||sum(isnan(temp)))
                Hybridization_flag=0;
                continue;
            else
                pos(i,:) = temp';
            end
        else
            velocity(i,:)=inw.*velocity(i,:)+c*rand(1,Dim).*(OO-pos(i,:));
            velocity(i,velocity(i,:)>velocityelocity_max) = velocityelocity_max;
            velocity(i,velocity(i,:)<velocityelocity_min) = velocityelocity_min;
            pos(i,:) = pos(i,:) + velocity(i,:);
        end
        pos(i,pos(i,:)>UB) = UB;
        pos(i,pos(i,:)<LB) = LB;
      
        fitness(i)=feval(fhd,pos(i,:)',fun_num);
        fitcount=fitcount+1;
        everyfit(fitcount)=min(everyfit(fitcount-1),fitness(i));
        Pbest(i,:)=(fitness(i)<Pbest_val(i))*pos(i,:)+(fitness(i)>=Pbest_val(i))*Pbest(i,:);
        Pbest_val(i)=(fitness(i)<Pbest_val(i))*fitness(i)+(fitness(i)>=Pbest_val(i))*Pbest_val(i);
        count(i)=(fitness(i)>Pbest_val(i))+(fitness(i)>Pbest_val(i))*count(i);
        if Pbest_val(i)<Gbest_val
            best_improved=1;
        end
        Gbest=(fitness(i)<Gbest_val)*pos(i,:)+(fitness(i)>=Gbest_val)*Gbest;
        Gbest_val=(fitness(i)<Gbest_val)*fitness(i)+(fitness(i)>=Gbest_val)*Gbest_val;

        a=a-.004;
        if count(i)>=G
            count(i)=0;
                Ppos = pos(i,:);
                for n=1:Dim                   
                    X1=first_solution_position(n)+(a*2*rand()-a)*abs(rand()*first_solution_position(n)-pos(i,n)); % Equation (3.6)-part 1                    
                    X2=second_solution_position(n)+(a*2*rand()-a)*(abs(rand()*second_solution_position(n)-pos(i,n))); % Equation (3.6)-part 2 
                    X3=third_solution_position(n)+(a*2*rand()-a)*(abs(rand()*third_solution_position(n)-pos(i,n))); % Equation (3.6)-part 2
                    Ppos(n)=(X1+X2+X3)/3;
                end
                Ppos(Ppos>UB) = UB;
                Ppos(Ppos<LB) = LB;
                Ppos_fit=feval(fhd,Ppos',fun_num);
                fitcount=fitcount+1;
                everyfit(fitcount)=min(everyfit(fitcount-1),Ppos_fit);
                
                pos(i,:)=Ppos*(Ppos_fit<fitness(i))+pos(i,:)*(1-(Ppos_fit<fitness(i)));
                fitness(i)=Ppos_fit*(Ppos_fit<fitness(i))+fitness(i,:)*(1-(Ppos_fit<fitness(i)));
                Pbest(i,:)=Ppos*(Ppos_fit<Pbest_val(i))+Pbest(i,:)*(1-(Ppos_fit<Pbest_val(i)));
                Pbest_val(i)=Ppos_fit*(Ppos_fit<Pbest_val(i))+Pbest_val(i,:)*(1-(Ppos_fit<Pbest_val(i)));

        end
        if  iter<=0.9*Maxiter
            velocity(i,:)= (abs(velocity(i,:))>10^(-4)).* velocity(i,:)+(1-(abs(velocity(i,:))>10^(-4))).*normrnd(0,1,[1,Dim]);
        end
    end
    improved = max(0,fitold-fitness);
    improved(elite)=0;
    pso_improved(1) = sum(improved(Class_Select_Index))/sum(Class_Select_Index);
    pso_improved(2) = sum(improved(~Class_Select_Index))/sum(~Class_Select_Index);
    Probs=pso_improved./sum(pso_improved);
    Probs = max(0.2, min(0.8,Probs));
   
    fitold=fitness;
    popold = pos;
    if best_improved
        best_stop = 0;
    else
        best_stop = best_stop+1;
    end


    %% update CMA parameters
    mu = pop_size/2;               % number of parents/points for recombination
    weights = log(mu+1/2)-log(1:mu)'; % muXone array for weighted recombination
    mu = floor(mu);
    weights = weights/sum(weights);     % normalize recombination weights array
    mueff=sum(weights)^2/sum(weights.^2); % variance-effectiveness of sum w_i x_i
    
    %% CMAES Adaptation
    if(Hybridization_flag==1)
        % Sort by fitness and compute weighted mean into xmean
        [~, popindex] = sort(fitness);  % minimization
        xold = xmean;
        xmean = popold(popindex(1:mu),:)' * weights;  % recombination, new mean value
        
        % Cumulation: Update evolution paths
        ps = (1-cs) * ps ...
            + sqrt(cs*(2-cs)*mueff) * invsqrtC * (xmean-xold) / sigma;
        hsig = sum(ps.^2)/(1-(1-cs)^(2*fitcount/pop_size))/problem_size < 2 + 4/(problem_size+1);
        pc = (1-cc) * pc ...
            + hsig * sqrt(cc*(2-cc)*mueff) * (xmean-xold) / sigma;
        
        % Adapt covariance matrix C
        artmp = (1/sigma) * (popold(popindex(1:mu),:)' - repmat(xold,1,mu));  % mu difference vectors
        C = (1-c1-cmu) * C ...                   % regard old matrix
            + c1 * (pc * pc' ...                % plus rank one update
            + (1-hsig) * cc*(2-cc) * C) ... % minor correction if hsig==0
            + cmu * artmp * diag(weights) * artmp'; % plus rank mu update
        
        % Adapt step size sigma
        sigma = sigma * exp((cs/damps)*(norm(ps)/chiN - 1));
        if isinf(sigma)
            sigma=0.5;
        end
        % Update B and D from C
        if fitcount - eigeneval > pop_size/(c1+cmu)/problem_size/10  % to achieve O(problem_size^2)
            eigeneval = fitcount;
            C = triu(C) + triu(C,1)'; % enforce symmetry
            if(sum(sum(isnan(C)))>0 || sum(sum(~isfinite(C)))>0 || ~isreal(C))
                Hybridization_flag=0;
                continue;
            end
            [B,D] = eig(C);           % eigen decomposition, B==normalized eigenvectors
            D = sqrt(diag(D));        % D contains standard deviations now
            invsqrtC = B * diag(D.^-1) * B';
        end
        
    end
    
    %% ============================ LS2 ====================================
    if fitcount>0.6*MaxFES && best_stop>K
        best_stop=0;
        old_fitcount=fitcount;
        if ~isnan(Gbest_val)
            [Gbest,Gbest_val,fitcount,succ] = LS2 (Gbest,Gbest_val,fitcount,fun_num,MaxFES,xmin,xmax);

            if succ==1 %% if LS2 was successful
                list_ind = randperm(N,1);
                pos(list_ind,:)=Gbest;
                fitness(list_ind)=Gbest_val;
%                 prob_ls=0.1;
            else
                K=K+100;
                pos=rand(N,Dim).*(UB-LB)+LB;
                for i=1:N
                    fitness(i)=feval(fhd,pos(i,:)',fun_num);
                    pos_2(i,:) = UB+LB-pos(i,:);
                    fitness_2(i)=feval(fhd,pos_2(i,:)',fun_num);
                    fitcount=fitcount+2;
                    if fitness_2(i)<fitness(i)
                        fitness(i) = fitness_2(i);
                        pos(i,:)=pos_2(i,:);
                    end
                end                
            end
            everyfit(old_fitcount:fitcount)=min(everyfit(old_fitcount-1),Gbest_val);
        end
    end
    if(Hybridization_flag==0)
        fitcount;
    end
    if fitcount>=MaxFES
        break;
    end
    if (iter==Maxiter) & (fitcount<MaxFES)
        iter=iter-1;
    end
end
everyfit=everyfit(1:MaxFES);
Gbest_val=everyfit(1,MaxFES);
end

