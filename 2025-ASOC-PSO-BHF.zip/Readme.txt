Paper Title: A particle swarm optimization-based ensemble metaheuristic for long-term transmission network expansion planning

https://www.sciencedirect.com/science/article/pii/S1568494625005939?dgcid=author

Anyone clicking on this link (https://authors.elsevier.com/a/1lCeY5aecSzA5p) before July 23, 2025 will be taken directly to the final version of your article on ScienceDirect, which they are welcome to read or download.

Volume 179, July 2025, 113282