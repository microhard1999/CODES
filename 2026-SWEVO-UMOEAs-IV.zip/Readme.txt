Paper Title: A variant of united multi-operator evolutionary algorithms with application to livestock feed ration optimization

https://www.sciencedirect.com/science/article/pii/S2210650225003955

Swarm and Evolutionary Computation, Volume 100, January 2026, 102238