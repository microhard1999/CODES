%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%  Implementation of UMOEAs-IV
%%
%%  See the details of UMOEAs-IV in the following paper
%%  Libin HONG and Dongxu ZHANG
%%  2025 
%%
%%  If you have any questions about the code, please contact: 
%%  Prof. Libin HONG at Libin.Hong@hznu.edu.cn or Libin.Hong@nottingham.edu.cn
%%  Dongxu ZHANG at dxuzhang@163.com
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc
clear
%%
for D = [10 30 50]    
outcome=zeros(51,30);
result=zeros(30,5);
for I_fno = 1:30
    for run = 1:51
        fprintf('run =\t %d function =%d dim =\t %d\n',run,I_fno,D);
        [bestold]=UMOEAsIV(run,I_fno,D);
        outcome(run,I_fno) = bestold;
    end    
    result(I_fno,1)=  min(outcome(:,I_fno));
    result(I_fno,2)=  max(outcome(:,I_fno));
    result(I_fno,3)=  median(outcome(:,I_fno));
    result(I_fno,4)=  mean(outcome(:,I_fno));
    result(I_fno,5)=  std(outcome(:,I_fno));

    file_name=sprintf('result\\UMOEAs-IV_%sD.mat',int2str(D));
    save(file_name,'outcome');

    name1 = 'result\\results_stat_';
    name2 = num2str(D);
    f_name=strcat(name1,name2);
    save(f_name, 'result');
end
end