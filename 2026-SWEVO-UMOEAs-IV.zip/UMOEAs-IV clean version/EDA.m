function [popold,fitness,pop_size,bsf_fit_var,bsf_solution,nfes,Par_restart]=EDA(popold,fitness,pop_size,problem_size,nfes,max_nfes,I_fno,bsf_fit_var,bsf_solution,Par_restart)

[fitness, fidx] = sort(fitness);
popold = popold(fidx, :);
Par_restart.counter = Par_restart.counter(fidx,:);
%% Determine the number of sampling individuals
PApnum=max(2, ceil(0.5 * pop_size));
if PApnum<2*problem_size
    PApnum=pop_size;
end
%% Determine the number of individuals to generate.
p=0.085+0.085*nfes/max_nfes;
pnum=max(2, round(p * pop_size));
newIndividual_num = max(1, ceil(0.9 * pnum)); 
%% Calculate the mean vector mu and covariance matrix C_matrix.
selection_pos = popold(1:PApnum,:);
mu = mean(selection_pos, 1);
mu_matrix=repmat(mu,PApnum,1);
temp_C=selection_pos-mu_matrix;
C_matrix =(temp_C'*temp_C)/(PApnum-1);
C_matrix = triu(C_matrix) + transpose(triu(C_matrix,1));
%% Sampling new individuals from a multivariate normal distribution.
temp_pos = mvnrnd(mu,C_matrix,newIndividual_num);          
%% Checking bound-constraints
lb=(-100).*ones(problem_size,1);
ub=(100).*ones(problem_size,1);
UB=repmat(ub,1,newIndividual_num);LB=repmat(lb,1,newIndividual_num);Ran=rand(problem_size,newIndividual_num);
temp_index1 = temp_pos > UB';
temp_index2 = temp_pos < LB';
temp_index = temp_index1 | temp_index2;
temp_pos(temp_index) = Ran(temp_index).*(UB(temp_index)-LB(temp_index))+LB(temp_index);
%% ==================calc. fit. and store the best ======================
fitness_EDA =cec17_func(temp_pos',I_fno);

for i = 1 : newIndividual_num
    nfes = nfes + 1;
    if fitness_EDA(i) < bsf_fit_var
        bsf_fit_var = fitness_EDA(i);
        bsf_solution = temp_pos(i, :);
    end
    if nfes > max_nfes; break; end
end

popold = [popold;temp_pos];
fitness = [fitness,fitness_EDA];
Par_restart.counter =[Par_restart.counter;zeros(newIndividual_num, 1)];

[fitness,index]=sort(fitness);
popold=popold(index,:);
Par_restart.counter = Par_restart.counter(index,:);
pop_size = pop_size + newIndividual_num;