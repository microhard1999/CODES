function [x,f,current_eval,succ] = LS2 (bestx,f,current_eval,I_fno,Max_FES,xmin,xmax)

LS_FE=ceil(15.0000e-003*Max_FES ); %% Max FEs_LS
options=optimset('Display','off','algorithm','sqp','UseParallel','never','MaxFunEvals',LS_FE) ;

[Xsqp, FUN , ~ , details]=fmincon(@cec17_func, bestx(1,:)',[],[],[],[],xmin,xmax,[],options,I_fno);

%% check if there is an improvement in the fitness value and update P_{ls}
if (f-FUN)>0
    succ=1;
    f = FUN;
    x(1,:)=Xsqp;
else
    succ=0;
    x=bestx;   
end
%% update FFEs
current_eval=current_eval+details.funcCount;
end