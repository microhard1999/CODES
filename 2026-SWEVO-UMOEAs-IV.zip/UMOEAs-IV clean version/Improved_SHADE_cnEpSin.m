function [x,fitx,prob,bestold,bestx,archive,hist_pos,memory_size,pArchive,current_eval,Par_restart,failure_ratio] = ...
    Improved_SHADE_cnEpSin(x,fitx,prob,bestold,bestx,archive,hist_pos,memory_size,pArchive,xmin,xmax,n,gen,...
    PopSize,current_eval,I_fno,Max_FES,Par_restart,failure_ratio)

pc=0.5;
LP = 15;
mem_rand_index = ceil(memory_size * rand(1,PopSize));
mu_cr = pArchive.CR(mem_rand_index);
mu_T = pArchive.T(mem_rand_index);
%% Cr adaption
cr = normrnd(mu_cr,0.1);
cr = min(cr, 1);
cr = max(cr, 0);
%% F adaption
mu_f = 0.35 + 0.3 * (2 ./ (1 + exp(-10 * (1 - failure_ratio))) - 1);
mu_f = mu_f(ones(PopSize, 1));
F = normrnd(mu_f,0.02);
pos = find(F <= 0);
while ~ isempty(pos)
    F(pos) = normrnd(mu_f(pos),0.02);
    pos = find(F <= 0);
end          
%% CR update, from EBOwithCMAR.
T = normrnd(mu_T,0.1);
T = max(T,0)'; T = min(T,0.5)';
l = floor(n*rand(1,PopSize))+1;
CR = [];
if n == 1
    CR = cr;
else
    for i = 1:PopSize
        if rem(n,2) == 0
           mm = exp(-T(i)/n*(0:n/2-1));
           ll = cr(i).*[mm fliplr(mm)];
           CR(i,[l(i):n (1:l(i)-1)]) =ll;
        else
           mm = exp(-T(i)/n*(0:floor(n/2-1)));
           mm1 = exp(-T(i)/n*floor(n/2));
           ll = cr(i).*[mm mm1 fliplr(mm)];
           CR(i,[l(i):n (1:l(i)-1)]) =ll;
        end
    end
end
%% ======================== generate r1,r2 =================================
popAll = [x;archive.pop]; 
r0 = 1 : PopSize;
[r1, r2, ~] = gnR1R2(PopSize, size(popAll, 1), r0);
%% Mutation
vi=zeros(PopSize,n);
bb= rand(PopSize, 1);
probiter = prob(1,:);
op_1 = bb <=  probiter(1)*ones(PopSize, 1);
op_2 = bb > probiter(1)*ones(PopSize, 1);

pNP = max(round(0.1 * PopSize), 2);        %% choose at least two best solutions
randindex = ceil(rand(1, PopSize) .* pNP); %% select from [1, 2, 3, ..., pNP]
randindex = max(1, randindex);             %% to avoid the problem that rand = 0 and thus ceil(rand) = 0
phix = x(randindex, :);                    %% randomly choose one of the top 10% solutions

% DE/current-to-ordpbest-weight/1
EDEpNP = max(round(0.1 * PopSize), 2);           %% choose at least two best solutions
EDErandindex = ceil(rand(1, PopSize) .* EDEpNP); %% select from [1, 2, 3, ..., EDEpNP]
EDErandindex = max(1, EDErandindex);             %% to avoid the problem that rand = 0 and thus ceil(rand) = 0
[~, sorted_index] = sort(fitx', 'ascend');
EDEpestind=sorted_index(EDErandindex);
R1 = Gen_R(PopSize,2);
R1(:,1)=[];
R1=[R1 EDEpestind];
fitness=fitx';
fr=fitness(R1);
[~,I1] = sort(fr,2);
R_S=[];
for i=1:PopSize
    R_S(i,:)=R1(i,I1(i,:));
end
rb=R_S(:,1)';
rm=R_S(:,2)';
rw=R_S(:,3)';
            
vi(op_1==1,:) = x(op_1==1,:) + F(op_1==1, ones(1, n)) .* (x(rb(op_1==1), :) - x(op_1==1,:) + x(rm(op_1==1), :) - x(rw(op_1==1), :)); 

% DE2 -- current-to-pbest/archive
vi(op_2==1,:) = x(op_2==1,:)+ F(op_2==1, ones(1, n)) .*(phix(op_2==1,:) - x(op_2==1,:) + x(r1(op_2==1), :) - popAll(r2(op_2==1), :));

% handle boundaries
vi = han_boun(vi,xmax,xmin,x,PopSize,1,n);

%% crossover
J_= mod(floor(rand(PopSize, 1)*n), n) + 1;
J = (J_-1)*PopSize + (1:PopSize)';
crs = rand(PopSize, n) < CR;

if rand<pc
    niche = Species_Based(x,PopSize,0.5);
    SEL=size(niche,1); xmean=mean(niche);
    C =  1/(SEL-1)*(niche - xmean(ones(SEL,1), :))'*(niche - xmean(ones(SEL,1), :));
    C = triu(C) + transpose(triu(C,1)); 
    [B,V] = eig(C);
    if max(diag(V)) > 1e20*min(diag(V))
        tmp = max(diag(V))/1e20 - min(diag(V));
        C = C + tmp*eye(n);
        [B, ~] = eig(C);
    end
    xt = x*B;
    vt = vi*B;
    ui = xt; ui(J)=vt(J); ui(crs)=vt(crs);
    ui = ui*B';
else
    ui = x;
    ui(J) = vi(J);
    ui(crs) = vi(crs);
end
ui = han_boun(ui,xmax,xmin,x,PopSize,1,n); 
%% ================== Evaluation with FE control ==================
remaining_FEs = Max_FES - current_eval;

if remaining_FEs <= 0
    return;
end

if remaining_FEs < PopSize
    eval_num = remaining_FEs;

    fitness_part = cec17_func(ui(1:eval_num,:)',I_fno);
    fitness_part = fitness_part(:)';

    [part_best,part_idx] = min(fitness_part);

    if part_best < bestold
        bestold = part_best;
        bestx = ui(part_idx,:);
    end

    current_eval = current_eval + eval_num;
    return;
end

fitness_new = cec17_func(ui',I_fno);
fitness_new = fitness_new(:)';

current_eval = current_eval + PopSize;

[new_best,new_best_idx] = min(fitness_new);
if new_best < bestold
    bestold = new_best;
    bestx = ui(new_best_idx,:);
end

%% calc. imprv. for Cr and failure_ratio
diff = abs(fitx - fitness_new);
I =(fitness_new < fitx);
failure_ratio = sum(I == 0) / PopSize;
goodCR = cr(I == 1);
goodT= T(I==1)';
%% ========================= update archive ===============================
archive = updateArchive(archive, x(I == 1, :), fitx(I == 1)');
%% ============ Store the current average value of fitness improvement in this round =============
diff2 = max(0,(fitx - fitness_new))./abs(fitx);
count_S(1)=max(0,mean(diff2(op_1==1)));
count_S(2)=max(0,mean(diff2(op_2==1)));

pArchive.m1(1:14) = pArchive.m1(2:15);  
pArchive.m1(15) = count_S(1);  
pArchive.m2(1:14) = pArchive.m2(2:15);  
pArchive.m2(15) = count_S(2); 

%% update probs.
if (gen < LP)    
    if count_S~=0 
        prob= max(0.1,min(0.9,count_S./(sum(count_S))));
    else
        prob=1/2 * ones(1,2);
    end
else    
    search_progress = current_eval / Max_FES;
    decay_rate = 0.15 + 0.2 * search_progress; 
    weights_mu = exp(decay_rate*(1:15)); 
    weights_mu = weights_mu / sum(weights_mu);
    
    count_S(1) = (weights_mu * ((pArchive.m1)' .^ 2))./ (weights_mu * (pArchive.m1)');
    count_S(2) = (weights_mu * ((pArchive.m2)' .^ 2))./ (weights_mu * (pArchive.m2)');
    
    if count_S~=0 
        prob= max(0.1,min(0.9,count_S./(sum(count_S))));
    else
        prob=1/2 * ones(1,2);
    end
end
%% =================== update memory CR��T =============================
num_success_params = numel(goodCR);
if num_success_params > 0
    weightsDE = diff(I == 1)./ sum(diff(I == 1));

    %%for updating the memory of crossover rate
    if max(goodCR) == 0 || pArchive.CR(hist_pos)  == -1
        pArchive.CR(hist_pos)  = -1;
    else
        pArchive.CR(hist_pos) = (weightsDE * (goodCR .^ 2)) / (weightsDE * goodCR);
    end
    
    %%for updating the memory of T
    if sum(goodT)==0
        pArchive.T(hist_pos)=0;
    else
        pArchive.T(hist_pos) = (weightsDE * (goodT .^ 2)) ./ (weightsDE * goodT);
    end
    
    hist_pos= hist_pos+1;
    if hist_pos > memory_size;  hist_pos = 1; end
end
%% ========= update x and fit ========
x(I==1,:)=ui(I==1,:);
fitx(I==1)=fitness_new(I==1);
 %% ======== Stagnation of individual updates ========
[~, bes_l]=min(fitx);
[x,fitx,Par_restart,current_eval,bestold,bestx]=Stagnation_renew(x,fitx,Par_restart,I,bes_l,current_eval,Max_FES,I_fno,n,bestold,bestx,xmax,xmin);
%% ========= sort x and fit ==========
[fitx,index]=sort(fitx);
x=x(index,:);
Par_restart.counter = Par_restart.counter(index,:);