function [x,fitx,Par_restart,g,bestold,bestx]=Stagnation_renew(x,fitx,Par_restart,I,gbestid,g,gmax,func,dim,bestold,bestx)
[PopSize,n] = size(x);
ratio = g/gmax;
Threshold = roundn((4.5*dim)/(dim+400),-1);
STE = max(ceil( 97*log(dim)-294 ),36);
%% ========== Stagnation count ==========
for i = 1:PopSize
    if I(i) == 0
        Par_restart.counter(i) = Par_restart.counter(i) + 1;
    else
        Par_restart.counter(i) = 0;
    end
end
%% ========== Gaussian distribution and vertical intersection ==========
if ratio < Threshold
    for i = 1:PopSize
        if  Par_restart.counter(i) > STE && i ~= gbestid
            %% Gaussian 
            [sort_fitx,index]=sort(fitx, 'ascend');
            rank_i = find(sort_fitx == fitx(i), 1);
            
            randindex = ceil(rand * rank_i); 
            randindex = max(1, randindex);
            BetterPoint = x(index(randindex), :);

            x_new = normrnd(BetterPoint, (log(g)/g)*(abs(x(i,:) - BetterPoint)), [1 size(x(i,:),2)]) + (randn*x(i,:) - randn*BetterPoint);
            fitx_new = cec17_func(x_new',func);
            g = g + 1;
            x(i,:) = x_new;
            fitx(i) = fitx_new;
            Par_restart.counter(i)=0;
            if fitx_new < bestold
                bestold = fitx_new;
                bestx = x_new;
            end
        end
    end
else
    for i = 1:PopSize
        if  Par_restart.counter(i) > STE && i ~= gbestid
                %% randomly select the dimensions to be perturbed
                nDim_j = randi(n);
                nSeq_j=randperm(n);
                j=nSeq_j(1:nDim_j);
                [~,j_size] = size(j);
                x_new = x(i,:);
                
                %% Randomly select other individuals in the same dimension to crossover with stagnant individuals.
                for j1 = 1:j_size
                    j_num = j(1,j1);
                    pop_num = x(:,j_num);
                    pop_num_1 = pop_num(randperm(numel(pop_num),1));
                    pop_num_11 = x(i,j_num);
                    x_new(1,j_num) = rand * pop_num_11 + (1-rand)*pop_num_1; 
                end
                fitx_new = cec17_func(x_new',func);
                g = g + 1;
                if fitx_new < fitx(i)
                    x(i,:) = x_new;
                    fitx(i) = fitx_new;
                    Par_restart.counter(i)=0;
                    if fitx_new < bestold
                        bestold = fitx_new;
                        bestx = x_new;
                    end
                end             
        end
    end
end