clc
format SHORTENG;
%%  introductory Definitions
num_prbs = 30;                      %% number of test problems
max_runs=51;                        %% number of runs

%% ========================= main loop ====================================
for D = [10 30 50 100]
    for i = [1:num_prbs]
        for run=1:max_runs  
            func_num=i;
            fprintf('run =\t %d\n',run);
            [best,bestvalue]=IMPSO_BIN(run,i,D);
            fprintf('bestval =\t %d\n',bestvalue);
        end  
    end
end




