function [bestx,bestold]= IMPSO_BIN(run,I_fno,dim)
Par= Introd_Par(I_fno,dim);
iter=0;             %% current generation
stream = RandStream('mt19937ar','Seed',sum(100*clock)*run);
RandStream.setGlobalStream(stream);
%% to record seeds for further validation, if needed
seed_run=stream.Seed; 

%% define variables
current_eval=0;             %% current fitness evaluations
PS1=Par.PopSize;            %% define PS1
PS2=4+floor(3*log(Par.n));  %% define PS2
Par.PopSize=PS1+PS2;        %% PS = PS1+PS2

%% ====================== Initalize x ==================================
x=repmat(Par.xmin,Par.PopSize,1)+repmat((Par.xmax-Par.xmin),Par.PopSize,1).*rand(Par.PopSize,Par.n);

%% calc. fit. and update FES

fitx = cec17_func(x',I_fno);
current_eval =current_eval+Par.PopSize;
%% ====================== store the best ==================
[bestold, bes_l]=min(fitx);     bestx= x(bes_l,:);

%% ================== fill in for each  phase butterfly ===================================
%% DE
EA_1= x(1:PS1,:);    EA_obj1= fitx(1:PS1);   EA_1old = x(randperm(PS1),:);
%% ES
EA_2= x(PS1+1:size(x,1),:);    EA_obj2= fitx(PS1+1:size(x,1));

Vmax0=0.5*(Par.xmax-Par.xmin);
%% Inertial Weight
w_max=0.9;
w_min=0.4;
xx=rand;
%% Learning Factor
c1=2;
c2=c1;
Vmax=repmat(Vmax0,PS1,1);
V=-Vmax+2*Vmax.*rand(PS1,Par.n);

%% Initialize Pbest and Gbest
Pbest=EA_1;   
fPbest=EA_obj1;
e_ps = 0.2*PS1;
gbest_stop=0;  %Number of population stagnation of IMPSO
cycle=5;       %%Policy change threshold
estate=1;      %Which speed update policy is used by IMPSO
InitPop=PS1;

%% ================ define CMA-ES parameters ==============================
setting=[];bnd =[]; fitness = [];
[setting]= init_cma_par(setting,EA_2, Par.n, PS2);


%% ===== prob. of each scout variant
probSC = 1./Par.n_opr .* ones(1,Par.n_opr);

stop_con=0; InitPop=PS1; 

cy=0;indx = 0; Probs=ones(1,2);

%% main loop
while stop_con==0;
    
    iter=iter+1;
    cy=cy+1; % to control CS
    ratio = current_eval / Par.Max_FES;
    %  ================ determine the best phase ===========================
    if(cy==ceil(Par.CS+1))
        list_ind_pso = randperm(PS1,1);
        list_ind_cmar = randperm(PS2,1);
        
        qual(1) = EA_obj1(list_ind_pso);qual(2) = EA_obj2(list_ind_cmar);
        norm_qual = qual./sum(qual);
        norm_qual=1-norm_qual; %% to satisfy the bigger is the better
        
        %%Normalized diversity
        D(1) = mean(pdist2(EA_1([1:list_ind_pso-1 list_ind_pso+1:PS1],:),EA_1(list_ind_pso,:)));
        D(2) = mean(pdist2(EA_2([1:list_ind_cmar-1 list_ind_cmar+1:PS2],:),EA_2(list_ind_cmar,:)));
        norm_div= D./sum(D);
        
        %%Total Imp
        Probs=norm_qual+norm_div;
        %%Update Prob_MODE and Prob_CMAES
        Probs = max(0.1, min(0.9,Probs./sum(Probs)));
        
        [~,indx]=max(Probs);
        if Probs(1)==Probs(2)
            indx=0;%% no sharing of information
        end
        
        
    elseif cy==2*ceil(Par.CS)
        
        %% share information
        if indx==1
            list_ind = randperm(PS1);
            list_ind= list_ind(1:(min(PS2,PS1)));
            EA_2(1:size(list_ind,2),:)= EA_1(list_ind,:);
            EA_obj2(1:size(list_ind,2))= EA_obj1(list_ind);
            [setting]= init_cma_par(setting,EA_2, Par.n, PS2);
            setting.sigma= setting.sigma*(1- (current_eval/Par.Max_FES));
        else
            if (min (EA_2(1,:)))> -100 && (max(EA_2(1,:)))<100 %% share best sol. in EA_2 if it is feasible
                EA_1(PS1,:)= EA_2(1,:);
                EA_obj1(PS1)= EA_obj2(1);
                [EA_obj1, ind]=sort(EA_obj1);
                EA_1=EA_1(ind,:);
            end
            
        end
        %% reset cy and Probs
        cy=1;   Probs=ones(1,2);
    end

        
    %% ====================== perching and patrolling ============================
    if (current_eval<Par.Max_FES)
        if rand<Probs(1)
            %% =============================== NLR ===================================================
             UpdPopSize = round((Par.MinPopSize - InitPop) * ratio^(1-ratio) + InitPop);
            
            
            if PS1 > UpdPopSize
                reduction_ind_num = PS1 - UpdPopSize;
                if PS1 - reduction_ind_num <  Par.MinPopSize
                    reduction_ind_num = PS1 - Par.MinPopSize;
                   
                end
                %% remove the worst ind.
                for r = 1 : reduction_ind_num
                    vv=PS1;
                    EA_1(vv,:)=[];
                    EA_obj1(vv)=[];
                    Pbest(vv,:)=[];
                    fPbest(vv)=[];
                    V(vv,:)=[]; 
                    PS1 = PS1 - 1;
                end
                e_ps = ceil(0.2*PS1);
            end
            
            %% apply IMPSO
            [EA_1, EA_obj1,bestold,bestx,Pbest,fPbest,xx,c1,c2,gbest_stop,cycle,estate,V,  current_eval] = MPSO(EA_1, EA_obj1,bestold,bestx,Pbest,fPbest,w_max,w_min,xx,c1,c2,e_ps,gbest_stop,cycle,estate,V, Par.xmin, Par.xmax ,Par.xmax ,Par.n,  PS1,  current_eval, I_fno,Par.Max_FES, Par.Gmax, iter);
        end
    end
    
    %% ====================== Scout/CMAR phase ======================
    if (current_eval<Par.Max_FES)
        if   rand<Probs(2)
            current_eval_tmp = current_eval;
            [ EA_2, EA_obj2, setting,bestold,bestx,bnd,fitness,current_eval] = ...
                Scout( EA_2, EA_obj2, probSC, setting, iter,bestold,bestx,fitness,bnd,...
                Par.xmin,Par.xmax,Par.n,PS2,current_eval,I_fno,Par.Max_FES);
        end
    end
    %% ============================ LS2 ====================================
    if current_eval>0.75*Par.Max_FES
        if rand<Par.prob_ls
            
            [bestx,bestold,current_eval,succ] = LS2 (bestx,bestold,Par,current_eval,I_fno,Par.Max_FES,Par.xmin,Par.xmax);
            if succ==1 %% if LS2 was successful
                EA_1(PS1,:)=bestx';
                EA_obj1(PS1)=bestold;
                [EA_obj1, sort_indx]=sort(EA_obj1);
                EA_1= EA_1(sort_indx,:);
                
                EA_2=repmat(EA_1(1,:), PS2, 1);
                [setting]= init_cma_par(setting,EA_2, Par.n, PS2);
                setting.sigma=1e-05;
                EA_obj2(1:PS2)= EA_obj1(1);
                Par.prob_ls=0.1;
            else
                Par.prob_ls=0.01; %% set p_LS to a small value it  LS was not successful
            end         
        end
    end
    
    %% ====================== stopping criterion check ====================
    if (current_eval>=Par.Max_FES)
        stop_con=1;
    end

end
end
