function [Par] = Introd_Par(I_fno,dim)

%% loading

Par.n_opr=2;  
Par.n=dim;     %% number of decision vriables


if Par.n==10
    Par.CS=50; %% cycle
    Par.Gmax = 2163;
elseif Par.n==30
    Par.CS=100; %% cycle
    Par.Gmax = 2745;
elseif Par.n==50
    Par.CS=150; %% cycle
    Par.Gmax = 3022;
else
    Par.CS=150; %% cycle
    Par.Gmax = 3401;
end

Par.xmin= -100*ones(1,Par.n);
Par.xmax= 100*ones(1,Par.n);
Par.Max_FES=Par.n*10000;
% Par.f_optimal=opt(I_fno);
% Par.PopSize=18*Par.n; %% population size
Par.PopSize=70; %% population size
Par.MinPopSize=10;
Par.prob_ls=0.1;
end