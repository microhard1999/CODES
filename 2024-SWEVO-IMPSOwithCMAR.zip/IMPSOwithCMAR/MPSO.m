function [X, fX,gbestValue,Gbest,Pbest,fPbest,xx,c1,c2,gbest_stop,cycle,estate,V,current_eval] = MPSO(X, fX,gbestValue,Gbest,Pbest,fPbest,w_max,w_min,xx,c1,c2,e_ps,gbest_stop,cycle,estate,V, Xmin, Xmax,Vmax,  dim,  PS1,  current_eval, I_fno,Max_FES,Gmax, iter)

%% Iteration
gbest_changed=0;%Record whether a better solution is produced
if gbest_stop>=cycle
    estate = ~estate;
    gbest_stop=0;
end
%% Update Position X and Velocity V and check the responding bounds
xx=4*xx*(1-xx);
w=xx*w_min+(w_max-w_min)*iter/Gmax;
if(estate)
    u=randperm(PS1,2);
    for i=1:PS1
        [U,index]=min(fPbest(u));
        if min(fPbest(u))<fPbest(i)
            Ubest(i,:)=Pbest(index,:);
        else
            Ubest(i,:)=Pbest(i,:);
        end
    end
    p1 = Ubest;
else
    
    [~,index]=sort(fPbest);
    for kk=1:PS1
        
        a = randi([1,e_ps],1,1);
        b = randi([1,e_ps],1,1);
        c = 0;
        while a == b
            b = randi([1,e_ps],1,1);
        end
        if fPbest(index(a)) < fPbest(index(b))
            cpbest(kk,:) = Pbest(index(a),:);
            c = index(a);
        else
            cpbest(kk,:) = Pbest(index(b),:);
            c = index(b);
        end
        
        if fPbest(kk) < fPbest(c)
            spbest(kk,:) = Pbest(kk,:);
        else
            spbest(kk,:) = cpbest(kk,:);
        end
    end
    p1 = spbest;
end



V=w*V+c1*rand(PS1,dim).*(p1-X)+c2*rand(PS1,dim).*(repmat(mean(Pbest),PS1,1)-X);

V=max(-Vmax,min(Vmax,V));
for i=1:PS1
    if exp(fX(i))/exp(mean(fX))>rand
        X(i,:)=w*X(i,:)+(1-w)*V(i,:)+Gbest;
    else
        X(i,:)=X(i,:)+V(i,:);
    end
end
X=max(Xmin,min(Xmax,X));



for i=1:PS1
    fX(i)=cec17_func(X(i,:)', I_fno);
    current_eval = current_eval+1;
end
[worst,index]=max(fX);
z=[1:index-1,index+1:PS1];
d=randperm(length(z),2);
j = fitnessDistanceBalance( X, fX );

NewX=X(j,:)+rand*(Pbest(z(d(2)),:)-Pbest(z(d(1)),:));
NewX=max(Xmin,min(Xmax,NewX));
fNewX=cec17_func(NewX',I_fno);
current_eval = current_eval+1;
if fNewX<worst
    X(index,:)=NewX;
    fX(index)=fNewX;
end
%% ==Evaluate Fitness and Change Pbest
for i=1:PS1
    if fX(i) < fPbest(i)
        Pbest(i,:)=X(i,:);
        fPbest(i)=fX(i);
    end
    if fPbest(i)<gbestValue
        Gbest=Pbest(i,:);
        gbestValue=fPbest(i);
        gbest_changed=1;
    end
end
if gbest_changed==1  % Update stagnation algebra
    gbest_stop=0;
else
    gbest_stop=gbest_stop+1;
end



end % end function    