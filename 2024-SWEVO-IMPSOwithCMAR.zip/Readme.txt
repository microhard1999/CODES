Title: Ensemble strategy using particle swarm optimisation variant and enhanced local search capability

DOI: 10.1016/j.swevo.2023.101452

https://www.sciencedirect.com/science/article/abs/pii/S2210650223002249?via%3Dihub

Note: The paper refers to the original release of 'f2', which contained bugs and was subsequently removed by the organizer. The version uploaded here is a revised edition of 'f2' that addresses those bugs.