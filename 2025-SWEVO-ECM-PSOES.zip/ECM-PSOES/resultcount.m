results = zeros(1,30);

for D = [ 10 30 50 100] %
    for j=1:30 % runs
       
     
        

        
        
        filename=sprintf('result/SQPPSO10_1problem%s_dim%s',num2str(j),num2str(D));
        resultc = load(filename,'result');
        results = mean(resultc.result);
        

    end 
    filename2=sprintf('SQPPSO__dim%s',num2str(D));
    save(filename2,'results');
end  