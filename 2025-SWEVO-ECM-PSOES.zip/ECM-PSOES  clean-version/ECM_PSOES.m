function [best_ans]=ECM_PSOES(NP,dim,max_FES,range,func_num)
    Xmax=range(2);
    Xmin=range(1);

    %% Parameter initialization
    w_max=0.9;w_min=0.4;
    pro_ls=0.07;

    %% Population initialization and evaluation
    pos=Xmin+(Xmax-Xmin).*rand(NP,dim);
    fitness=cec17_func(pos',func_num);
    fitness=fitness';
    succ=1;  
    %% Parameter initialization
    fitcount=NP;
    pbest_pos=pos;
    pbest_val=fitness;
    [gbest_val,gbest_id]=min(pbest_val);
    gbest_pos=pbest_pos(gbest_id,:);
    Vmax = 30;
    Vmin = -Vmax;
    V= Vmin+(Vmax-Vmin).*rand(NP,dim);
    ratio=0.5;
    T=0;
    NP1=NP*ratio;
    NP2=NP1;
    iter=1;
    xx=rand;
    while fitcount<max_FES
        T=T+1;
        ratio2 = fitcount / max_FES;
       %% Sort by fitness
        [~,index]=sort(fitness);
        pos = pos(index,:);
        V = V(index,:);
        pbest_pos = pbest_pos(index,:);
        pbest_val = pbest_val(index);

       %% =============================== NLR =======================================
        UpdPopSize = round((10 - NP) * ratio2^(1-ratio2) + NP);    
        if NP > UpdPopSize 
            reduction_ind_num = NP - UpdPopSize;
            if NP - reduction_ind_num <  10
                reduction_ind_num = NP - 10;       
            end
           %% Remove the worst ind.
            for r = 1 : reduction_ind_num
                vv=NP;
                pos(vv,:)=[];
                fitness(vv)=[];
                pbest_pos(vv,:)=[];
                pbest_val(vv)=[];
                V(vv,:)=[]; 
                p1(vv,:)=[];
                NP = NP - 1;
            end
                
        end
        %% Parameter initialization
        w = w_max - (w_max-w_min)*fitcount / max_FES;
        c1 =(2.5-2*fitcount / max_FES);
        c2 =(0.5+2*fitcount / max_FES);
        c3=dim/NP*0.01;
     
        r1 = rand(NP,1);
        r2 = rand(NP,1);
        r1 = repmat(r1,1,dim);
        r2 = repmat(r2,1,dim); 
        %% Preparation for SLPSO 
        center=ones(NP,1)*mean(pbest_pos);
        win_idx_mask=repmat((1:NP)',1,dim);
        win_idx=win_idx_mask+ceil(rand(NP,dim).*(NP-win_idx_mask));
        pos_win=pos;
        for j=1:dim
            pos_win(:,j)=pos(win_idx(:,j),j);
        end

        u=randperm(NP,2);
    
        for i=1:NP
            [U,index]=min(pbest_val(u));
            if min(pbest_val(u))<pbest_val(i)
                Ubest(i,:)=pbest_pos(index,:);
            else
                Ubest(i,:)=pbest_pos(i,:);
            end
        end
        p1 = Ubest;
        %% Update the velocity and position for MPSO
        V_temp1=w.*V+c1*rand(NP,dim).*(p1(1:NP,:)-pos)+c2*rand(NP,dim).*(repmat(mean(pbest_pos),NP,1)-pos);
        %% Update the velocity and position for SLPSO
        V_temp2=w*rand(NP,dim).*V+r1.*(pos_win-pos)+c3*r2.*(center-pos);

        for i=1:NP
            if exp(fitness(i))/exp(mean(fitness))>rand
                posTmp1(i,:)=w*pos(i,:)+(1-w)*V_temp1(i,:)+gbest_pos;
                posTmp2(i,:)=w*pos(i,:)+(1-w)*V_temp2(i,:)+gbest_pos;
            else
                posTmp1(i,:)=pos(i,:)+V_temp1(i,:);
                posTmp2(i,:) = pos(i,:) + V_temp2(i,:);
            end
        end
        bnd=floor(NP*ratio);
        V(1:bnd,:)=V_temp1(1:bnd,:);
        V(bnd+1:NP,:)=V_temp2(1:NP-bnd,:);
        pos(1:bnd,:)=posTmp1(1:bnd,:);
        pos(bnd+1:NP,:)=posTmp2(1:NP-bnd,:);
        %% Boundary processing function
        pos = ((pos>=Xmin)&(pos<=Xmax)).*pos...
          +(pos<Xmin).*(Xmin+0.25.*(Xmax-Xmin).*rand(NP,dim))+...
          +(pos>Xmax).*(Xmax-0.25.*(Xmax-Xmin).*rand(NP,dim));
     
        %% Evaluate fitness value
        fitness=cec17_func(pos',func_num);
        fitness=fitness';
        fitcount=fitcount+NP;
        %% Update the ratio per cycle
        NP1=floor(ratio*NP);
        NP2=NP-NP1;
        fitx1=fitness(1:NP1);
        fitx2=fitness(NP1+1:NP);
        pos1=pos(1:NP1,:);
        pos2=pos(NP1+1:NP,:);
    
        if mod(T,NP/2)==0
            %% Quantify the fitness value and normalized
            qual(1)=fitx1(1);
            qual(2)=fitx2(1);
            norm_qual=qual./sum(qual);
            norm_qual=1-norm_qual;
            %% Quantify the diversity and normalized
            D(1)=mean(pdist2(pos1(2:NP1,:),pos1(1,:)));
            D(2)=mean(pdist2(pos2(2:NP2,:),pos2(1,:)));
            norm_div=D./sum(D);
            %% update the ratio
            probs=norm_qual+norm_div;
            ratio=max(0.2,min(0.8,probs./sum(probs)));
            ratio=ratio(1);
        end
        %% update pbest and gbest
        bin=(pbest_val>fitness)';
        pbest_pos(bin==1,:)=pos(bin==1,:);
        pbest_val(bin==1)=fitness(bin==1);
        [gbest_val,gbest_id]=min(pbest_val);
        gbest_pos=pbest_pos(gbest_id,:);
       
        %% Mutation ratio is 20%
        bnd2=ceil(NP*0.2);
        for i=1:bnd2
            rk1=floor(NP*rand)+1;
            rk2=floor(rk1*rand)+1;
            rk3=floor(rk2*rand)+1;
            ff=1-0.3*fitcount/max_FES;
            pos(rk1,:)=pbest_pos(rk1,:)+ff*(pbest_pos(rk2,:)-pbest_pos(rk3,:)); 
        end
        
        %% Local Search: SQP
        if rand<pro_ls && fitcount>0.4*max_FES        
            if succ==1
                mbest_pos=gbest_pos;
                mbest_val=gbest_val;
            else
                a = 2;
                r1=a-fitcount*((a)/max_FES);
                r2=(2*pi)*rand();
                r3=2*rand;
                r4=rand();
                if r4<0.5   
                    mbest_pos=gbest_pos+(r1*sin(r2)*(r3*gbest_pos-pbest_pos(rk1,:)));
                    fitness2=cec17_func(mbest_pos',func_num);
                    mbest_val=fitness2';
                    if gbest_val>mbest_val
                        gbest_val=mbest_val;
                        gbest_pos=mbest_pos;
                        pos(gbest_id,:)=mbest_pos;
                        fitness(gbest_id)=mbest_val;
                        pbest_pos(gbest_id,:)=mbest_pos;
                        pbest_val(gbest_id,:)=mbest_val;
                    end
                    fitcount=fitcount+1;

                else               
                    mbest_pos=gbest_pos+(r1*cos(r2)*(r3*gbest_pos-pbest_pos(rk1,:)));
                    fitness2=cec17_func(mbest_pos',func_num);
                    mbest_val=fitness2';
                    if gbest_val>mbest_val
                        gbest_val=mbest_val;
                        gbest_pos=mbest_pos;
                        pos(gbest_id,:)=mbest_pos;
                        fitness(gbest_id)=mbest_val;
                        pbest_pos(gbest_id,:)=mbest_pos;
                        pbest_val(gbest_id,:)=mbest_val;
                    end
                    fitcount=fitcount+1;

                end
            end
            [new_pos,new_val,fitcount,succ]=local_search2(mbest_pos,gbest_val,fitcount,func_num,max_FES,Xmin,Xmax,dim);
            new_pos=new_pos';

            if succ==1  %% if Gbest is improved by SQP
                pro_ls=0.1*fitcount/max_FES;
                pos(gbest_id,:)=new_pos;
                fitness(gbest_id)=new_val;
                pbest_pos(gbest_id,:)=new_pos;
                pbest_val(gbest_id,:)=new_val;
                gbest_pos=new_pos;
                gbest_val=new_val; 
            else    %% if Gbest is not improved by SQP
                pro_ls=0.01*fitcount/max_FES;
            end
        end

        iter=iter+1;      
    end
    best_ans=gbest_val-func_num*100; %% Calculate the error       
end