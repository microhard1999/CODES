clear;
clc;
runs=51;
result=zeros(runs,30);
range=[-100,100];
for D = [10 30  50 100  ]
    for i=1:30 % problem
    func_num=i;
    for j=1:runs % runs
        fprintf('run =\t %d pro=%d dim=%d\n',j,i,D);
        [best_ans]=ECM_PSOES(100,D,D*10000,range,func_num);  
        fprintf('%1.9e\n',best_ans);
        result(j,i)=best_ans;
        filename=sprintf('result/ECM-PSOES_problem%s_dim%s',num2str(i),num2str(D));
        save(filename,'result');   
   end 
   end
end      
  

