Paper Title: An effective combination of mechanisms for particle swarm optimization-based ensemble strategy

sciencedirect.com/science/authShare/S2210650225003116/20250910T125100Z/1?md5=34cee2d1da96cca594bc73847bb23d71&dgcid=author

Anyone clicking on this link (https://authors.elsevier.com/a/1llKZ7sfCTOafi) before October 30, 2025 will be taken directly to the final version of your article on ScienceDirect, which they are welcome to read or download.

Swarm and Evolutionary Computation, Volume 99, December 2025, 102154