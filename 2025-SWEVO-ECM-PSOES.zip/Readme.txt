Paper Title: An effective combination of mechanisms for particle swarm optimization-based ensemble strategy

https://www.sciencedirect.com/science/article/abs/pii/S2210650225003116

Swarm and Evolutionary Computation, Volume 99, December 2025, 102154