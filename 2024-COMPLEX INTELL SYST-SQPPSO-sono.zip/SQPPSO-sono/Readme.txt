Title: A sequential quadratic programming based strategy for particle swarm optimization on single-objective numerical optimization

DOI: 10.1007/s40747-023-01269-z

https://link.springer.com/article/10.1007/s40747-023-01269-z?utm_source=rct_congratemailt&utm_medium=email&utm_campaign=oa_20231122&utm_content=10.1007/s40747-023-01269-z