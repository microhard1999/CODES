clear;
clc;

runs=1;
result=zeros(runs,30);

range=[-100,100];

for i=1:30 % problem
    fprintf('Problem =\t %d\n',i);
    value=zeros(500000,runs);
    func_num=i;
    for j=1:runs % runs
        fprintf('run =\t %d\n',j);
     
       [best_ans]=SQPPSO_sono(100,50,500000,range,func_num);  

        fprintf('%1.9e\n',best_ans);
        result(j,i)=best_ans;

   end 

end      
  

