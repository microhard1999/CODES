function [best_ans]=SQPPSO_sono(NP,dim,max_FES,range,func_num)
  Xmax=range(2);
  Xmin=range(1);
  max_iter=max_FES/NP;
  
  % parameter initialization
  w_max=0.9;w_min=0.4;
  pro_ls=0.1;
  
  %% Population initialization and evaluation
  pos=Xmin+(Xmax-Xmin).*rand(NP,dim);
  fitness=cec17_func(pos',func_num);
  fitness=fitness';
  
  % parameter initialization
  fitcount=NP;
  pbest_pos=pos;
  pbest_val=fitness;
  [gbest_val,gbest_id]=min(pbest_val);
  gbest_pos=pbest_pos(gbest_id,:);
  gbestrep = repmat(gbest_pos,NP,1);
  Vmax = 30;
  Vmin = -Vmax;
  V= Vmin+(Vmax-Vmin).*rand(NP,dim);
  
  ratio=0.5;
  T=0;
  NP1=NP*ratio;
  NP2=NP1;
  iter=2;
  
  while fitcount<max_FES
    T=T+1;
    
    %% sort by fitness
     [~,index]=sort(fitness,'descend');
     pos = pos(index,:);
     V = V(index,:);
     pbest_pos = pbest_pos(index,:);
     pbest_val = pbest_val(index);
     
     %% parameter initialization
     w = w_max - (w_max-w_min)*iter/max_iter;
     c1 =(2.5-2*iter/max_iter);
     c2 =(0.5+2*iter/max_iter);
     c3=dim/NP*0.01;
     
     r1 = rand(NP,1);
     r2 = rand(NP,1);
     r1 = repmat(r1,1,dim);
     r2 = repmat(r2,1,dim);
     
     %% preparation for SLPSO 
     center=ones(NP,1)*mean(pos);
     win_idx_mask=repmat((1:NP)',1,dim);
     win_idx=win_idx_mask+ceil(rand(NP,dim).*(NP-win_idx_mask));
     pos_win=pos;
     for j=1:dim
         pos_win(:,j)=pos(win_idx(:,j),j);
     end
     
     %% Update the velocity and position
     V_temp1=w.*V + c1.*r1.*(pbest_pos-pos) + c2.*r2.*(gbestrep-pos);
     posTmp1 = pos + V_temp1;  % w-PSO
     V_temp2=rand(NP,dim).*V+r1.*(pos_win-pos)+c3*r2.*(center-pos);
     posTmp2 = pos + V_temp2;  % SLPSO  
     
     bnd=floor(NP*ratio);
     V(1:bnd,:)=V_temp1(1:bnd,:);
     V(bnd+1:NP,:)=V_temp2(bnd+1:NP,:);
     pos(1:bnd,:)=posTmp1(1:bnd,:);
     pos(bnd+1:NP,:)=posTmp2(bnd+1:NP,:);
     
     %% Boundary processing function
     pos = ((pos>=Xmin)&(pos<=Xmax)).*pos...
            +(pos<Xmin).*(Xmin+0.25.*(Xmax-Xmin).*rand(NP,dim))+...
            +(pos>Xmax).*(Xmax-0.25.*(Xmax-Xmin).*rand(NP,dim));
     
     %% evaluation
     fitness=cec17_func(pos',func_num);
     fitness=fitness';
    
 %% Update the ratio once a cycle
         NP1=floor(ratio*NP);
         NP2=NP-NP1;
         fitx1=fitness(1:NP1);
         fitx2=fitness(NP1+1:NP);
         pos1=pos(1:NP1,:);
         pos2=pos(NP1+1:NP,:);
    
     if mod(T,NP/2)==0
         % Quantify the fitness value and normalized
            qual(1)=fitx1(1);
            qual(2)=fitx2(1);
            norm_qual=qual./sum(qual);
            norm_qual=1-norm_qual;
            
         % Quantify the diversity and normalized
            D(1)=mean(pdist2(pos1(2:NP1,:),pos1(1,:)));
            D(2)=mean(pdist2(pos2(2:NP2,:),pos2(1,:)));
            norm_div=D./sum(D);
            
         % update the ratio
            probs=norm_qual+norm_div;
            ratio=max(0.1,min(0.9,probs./sum(probs)));
            ratio=ratio(1);
     end
     
     %% update pbest and gbest
     bin=(pbest_val>fitness)';
     pbest_pos(bin==1,:)=pos(bin==1,:);
     pbest_val(bin==1)=fitness(bin==1);
     [gbest_val,gbest_id]=min(pbest_val);
     
     fitcount=fitcount+NP;

     gbest_pos=pbest_pos(gbest_id,:);
     
     
     %% Local Search: SQP
     if rand<pro_ls
         [new_pos,new_val,fitcount,succ]=local_search(gbest_pos,...
         gbest_val,fitcount,func_num,max_FES,Xmin,Xmax,dim);
         new_pos=new_pos';
       
         if succ==1  % if improved
             pro_ls=0.1;
             
             pos(gbest_id,:)=new_pos;
             fitness(gbest_id)=new_val;
             pbest_pos(gbest_id,:)=new_pos;
             pbest_val(gbest_id,:)=new_val;
             gbest_pos=new_pos;
             gbest_val=new_val;
             
         else    % not improved
             pro_ls=0.01;
         end
     end
     
     gbestrep = repmat(gbest_pos,NP,1);
     iter=iter+1;
     
  end
      best_ans=gbest_val-func_num*100; % Calculat the error
end