19th International Conference on Parallel Problem Solving From Nature
Paper Title
HERLMES: Heterogeneous Ensemble with Reinforcement Learning Mechanisms for Evolutionary Search
Authors
Mukuka Chanda Kapampa, John R. Woodward, and Libin Hong (Corresponding author)

@incollection{kapampa2026herlmes,
  title={HERLMES: Heterogeneous Ensemble with Reinforcement Learning Mechanisms for Evolutionary Search},
  author={Kapampa, Mukuka Chanda and Woodward, John R and Hong, Libin},
  booktitle={Parallel Problem Solving from Nature--PPSN XIX},
  pages={53--69},
  year={2026},
  publisher={Springer}
}