19th International Conference on Parallel Problem Solving From Nature
Paper Title
HERLMES: Heterogeneous Ensemble with Reinforcement Learning Mechanisms for Evolutionary Search
Authors
Mukuka Chanda Kapampa and Libin Hong (Corresponding author)