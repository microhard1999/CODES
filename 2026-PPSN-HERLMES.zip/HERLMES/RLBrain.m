classdef RLBrain
    properties
        Q       
        memory
        epsilon
        alpha = 0.1
        gamma = 0.95
        D
    end

    methods
        function obj = RLBrain(D)
            obj.D = D;
            obj.Q = zeros(1000,5,4);
            obj.memory = [];
            obj.epsilon = 1.0;
            assert(size(obj.Q,1)==1000,'Q-table row count ? 1000');
        end

        function action = select(obj,s_idx)
            if ~isscalar(s_idx) || isempty(s_idx), s_idx = 1; end
            s_idx = max(1,min(size(obj.Q,1),round(s_idx)));
            %fprintf('RLBrain-check  s_idx=%d  size(Q,1)=%d\n', s_idx, size(obj.Q,1));
            % ---- TRACER ----
            if s_idx > size(obj.Q,1)
                fprintf(2,'*** SELECT  s_idx=%d  max=%d\n',s_idx,size(obj.Q,1));
                s_idx = size(obj.Q,1);
            end
            % ----------------
            bin = min(4,ceil(log10(obj.D)));
            obj.epsilon = max(0.1, 0.9*exp(-size(obj.memory,1)/1000));
            if rand < obj.epsilon
                action = randi(5)-1;
            else
                [~,aid] = max(obj.Q(s_idx,:,bin));
                action = aid-1;
            end
        end

        function update(obj,s,a,r,s_next)
            if ~isscalar(s)||~isscalar(a)||~isscalar(r)||~isscalar(s_next), return; end
            s = max(1,min(size(obj.Q,1),round(s)));        % first clamp
            s_next = max(1,min(size(obj.Q,1),round(s_next)));
            % TRACER 
            if s>size(obj.Q,1) || s_next>size(obj.Q,1)
                %fprintf(2,'*** UPDATE  s=%d  s_next=%d  max=%d\n',s,s_next,size(obj.Q,1));
                s = min(s,size(obj.Q,1));  
                s_next = min(s_next,size(obj.Q,1));
            end
           
            a = max(0,min(4,round(a)));  a1 = a+1;
            obj.memory = [obj.memory; s,a1,r,s_next];
            if size(obj.memory,1)>2000, obj.memory(1:500,:) = []; end
            if size(obj.memory,1)<5, return; end
            batch = obj.memory(randsample(size(obj.memory,1),min(32,end)),:);
            bin = min(4,ceil(log10(obj.D)));
            for i = 1:size(batch,1)
                s_b = batch(i,1);  a_b = batch(i,2);  r_b = batch(i,3);  s_n = batch(i,4);
                
                %  EXTRA clamp for stale bad rows 
                s_b = max(1,min(size(obj.Q,1),s_b));
                s_n = max(1,min(size(obj.Q,1),s_n));
                a_b = max(1,min(5,a_b));
                % ----------------------------------------
                
                next_max = max(obj.Q(s_n,:,bin));
                td = r_b + obj.gamma*next_max - obj.Q(s_b,a_b,bin);
                obj.Q(s_b,a_b,bin) = obj.Q(s_b,a_b,bin) + obj.alpha*td;
            end
        end
    end
end