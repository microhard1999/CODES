clc; clear; 
close all; 
format shortEng;
num_prbs = 30; 
max_runs = 51; 
dimensions = [30, 100]; 
RecordFEsFactor = 0.001:0.001:1; 
progress = numel(RecordFEsFactor);

if ~exist('plot_dataV2','dir') 
    mkdir('plot_dataV2'); 
end

if ~exist('resultsV2','dir') 
    mkdir('resultsV2'); 
end

for D = dimensions
    fprintf('\n=== D = %d ===\n', D);
    result = zeros(max_runs, num_prbs);
    maxFEs = 10000 * D;
    swarm_size = max(40 + 2*D, 20);
    for f = 1:num_prbs
        fprintf('\n--- F%02d ---\n', f);
        allerrorvals = zeros(progress, max_runs);
        for run = 1:max_runs
            fprintf('  Run %2d/%2d  ', run, max_runs);
            try
                range = [-100, 100];
                func_num = f;
                [fmin, recordedScores] = HERLMES(swarm_size, D, range, RecordFEsFactor, maxFEs, progress, func_num);
                f_optimal = f * 100;
                error_val = fmin - f_optimal;
                result(run, f) = error_val;
                allerrorvals(:, run) = recordedScores - f_optimal;
                fprintf('  error = %12.4e\n', error_val);
            catch ME
                fprintf('  *** ERROR *** %s\n', ME.message);
                result(run, f) = NaN;
                allerrorvals(:, run) = NaN;
            end
        end
        save(sprintf('plot_dataV2/HERMES_plot_F%02d_dim%d.mat', f, D), ...
             'allerrorvals', 'RecordFEsFactor');
    end
    fprintf('Saving results: size(result) = [%d %d]\n', size(result));
    if ~isequal(size(result), [51, 30])
        error('result is NOT 51 30! It is %dx%d', size(result));
    end
    save(sprintf('resultsV2/HERMES_results_dim%d.mat', D), 'result');
end
fprintf('\n=== ALL DONE: HERMES BENCHMARK COMPLETE ===\n');