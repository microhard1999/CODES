classdef CMAES
    properties
        D, mean, sigma, C, B, D_vec, invsqrtC, ps, pc, eigeneval
        cc, cs, c1, cmu, damps, chiN
    end
    methods
        function obj = CMAES(D, mean0, sigma0)
            obj.D = D; 
            obj.mean = mean0; 
            obj.sigma = sigma0;
            obj.C = eye(D); 
            obj.B = eye(D); 
            obj.D_vec = ones(D,1);
            obj.invsqrtC = eye(D); 
            obj.ps = zeros(D,1); 
            obj.pc = zeros(D,1);
            obj.eigeneval = 0;
            mueff = 4; 
            obj.cc = (4 + mueff/D)/(D+4+2*mueff/D);
            obj.cs = (mueff+2)/(D+mueff+5);
            obj.c1 = 2/((D+1.3)^2 + mueff);
            obj.cmu = min(1-obj.c1, 2*(mueff-2+1/mueff)/((D+2)^2 + mueff));
            obj.damps = 1 + 2*max(0,sqrt((mueff-1)/(D+1))-1) + obj.cs;
            obj.chiN = D^0.5*(1-1/(4*D)+1/(21*D^2));
        end
        function [X_new, f_new, obj] = step(obj, lambda, lb, ub, fhd)
            mu = floor(lambda/2);
            weights = log(mu+0.5) - log(1:mu)'; 
            weights = weights/sum(weights);
            mueff = 1/sum(weights.^2);

            z = randn(obj.D, lambda);
            y = obj.B * (obj.D_vec .* z);
            X = obj.mean + obj.sigma * y;
            X = max(min(X, ub), lb);
            f = arrayfun(@(k) fhd(X(:,k)), 1:lambda);
            [f, idx] = sort(f);
            X = X(:,idx(1:mu)); 
            f = f(1:mu);

            xold = obj.mean;
            obj.mean = X * weights;
            ps = (1-obj.cs)*obj.ps + sqrt(obj.cs*(2-obj.cs)*mueff)*obj.invsqrtC*(obj.mean-xold)/obj.sigma;
            hsig = norm(ps)/sqrt(sum(ps.^2)) < 1.4 + 2/(obj.D+1);
            obj.pc = (1-obj.cc)*obj.pc + hsig*sqrt(obj.cc*(2-obj.cc)*mueff)*(obj.mean-xold)/obj.sigma;

            artmp = (X - xold)/obj.sigma;
            obj.C = (1-obj.c1-obj.cmu)*obj.C + obj.c1*(obj.pc*obj.pc' + (1-hsig)*obj.cc*(2-obj.cc)*obj.C) + obj.cmu*artmp*diag(weights)*artmp';

            obj.sigma = obj.sigma * exp((obj.cs/obj.damps)*(norm(ps)/obj.chiN - 1));

            if obj.eigeneval == 0 || rand < 1/(10*obj.D)
                obj.C = triu(obj.C) + triu(obj.C,1)';
                [obj.B, D] = eig(obj.C);
                obj.D_vec = sqrt(diag(D));
                obj.invsqrtC = obj.B * diag(1./obj.D_vec) * obj.B';
                obj.eigeneval = 1;
            end

            X_new = X; f_new = f;
        end
    end
end