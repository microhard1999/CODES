function [x, f, current_eval, succ] = LS2(bestx, f, current_eval, I_fno, Max_FES)
    LS_FE = ceil(0.02 * Max_FES);
    options = optimoptions('fmincon', 'Display', 'off', 'Algorithm', 'sqp', ...
        'UseParallel', false, 'MaxFunctionEvaluations', LS_FE);

    lb = -100 * ones(size(bestx));
    ub =  100 * ones(size(bestx));

    [Xsqp, FUN, ~, details] = fmincon(@(x) cec17_func(x, I_fno), bestx, [], [], [], [], lb, ub, [], options);

    if (f - FUN) > 0
        succ = 1; f = FUN; x = Xsqp;
    else
        succ = 0; x = bestx;
    end
    current_eval = current_eval + details.funcCount;
end