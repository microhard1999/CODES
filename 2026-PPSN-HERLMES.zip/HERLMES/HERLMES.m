function [fmin, recordedScores] = HERMES(swarm_size, D, range, RecordFEsFactor, maxFEs, progress, func_num)

    fhd      = @(x,fn) cec17_func(x,fn);
    fhd_col  = @(x) fhd(x(:),func_num);
    x_min    = range(1);
    x_max    = range(2);
    v_max    = 0.1*(x_max-x_min);

    %% ---------- RL BRAIN ----------
    agent = RLBrain(D);  %Dimension Aware

    %% ---------- INIT ----------
    X = x_min + (x_max-x_min)*rand(D,swarm_size);
    V = -v_max + 2*v_max*rand(D,swarm_size);
    fitness = arrayfun(@(i) fhd_col(X(:,i)),1:swarm_size)';
    [Gbest_f,idx] = min(fitness);  
    Gbest = X(:,idx);
    Pbest = X;  
    Pbest_f = fitness;

    cma = CMAES(D, mean(X,2), 0.3*(x_max-x_min));

    currentFEs = swarm_size;  
    t = 0;
    FEs_at_record = unique(round(RecordFEsFactor*maxFEs));
    FEs_at_record = FEs_at_record(FEs_at_record>swarm_size);
    record_idx = 1;  
    recordedScores = zeros(progress,1);  
    recordedScores(1) = Gbest_f;

    % success counters
    pso_success = 0; 
    cma_success = 0; 
    ipm_success = 0; 
    sqp_success = 0; 
    shaf_success = 0;
    total_success = 1e-10;
    Probs = [0.2 0.2 0.2 0.2 0.2];
    prev_Gbest = Gbest_f;  
    stagnation = 0;

    edges = linspace(0,1,1001);
    
    %% ========== MAIN LOOP ==========
    while currentFEs < maxFEs
        t = currentFEs/maxFEs;
        w = 0.9 - 0.5*t;
        diversity = std(fitness)/max(mean(fitness),eps);
        boundary_viol = mean(any(X<x_min | X>x_max,1));
        pso_rate = pso_success/max(1,Probs(1));
        cma_rate = cma_success/max(1,Probs(2));

        %% Dimension-aware state vector
        logD = log10(D);
        state_vec = [diversity, t, pso_rate, cma_rate, boundary_viol, stagnation>5, logD];
        norm_val = norm(state_vec);
        if norm_val < eps 
            state_vec = [0.1, t, 0.2, 0.2, 0, 0 ,logD]; 
            norm_val = norm(state_vec); 
        end
        state_norm = state_vec/norm_val;
        idx_raw = discretize(state_norm,edges);
        
        if isempty(idx_raw)||~isscalar(idx_raw) 
            state_idx = 1;
        else
            state_idx = max(1,min(1000,round(min(idx_raw,1000)))); 
        end
         
        if state_idx > size(agent.Q,1)
            state_idx = size(agent.Q,1);
        end
      
        action = agent.select(state_idx);
        improved = false;  
        old_fitness = fitness;

        %% Operator budgets scale
        scale = 1 + 0.5*(D>=50);

        switch action
        case 0 % PSO
            r1 = rand(D,swarm_size); 
            r2 = rand(D,swarm_size);
            V = w*V + 2*r1.*(Pbest-X) + 2*r2.*(Gbest-X);
            V = max(min(V,v_max),-v_max);
            X = X + V;  
            X = max(min(X,x_max),x_min);
            fitness = arrayfun(@(i) fhd_col(X(:,i)),1:swarm_size)';
            currentFEs = currentFEs + swarm_size*scale;
            improved = any(fitness<old_fitness);
            pso_success = pso_success + double(improved);

        case 1 % CMA-ES
            lambda = round(scale*max(15, 4 + floor(3*log(D))));
            [new_X,new_f,cma] = cma.step(lambda,x_min,x_max,fhd_col);
            mu = size(new_X, 2);
            num_replace = min(mu,swarm_size);
            if num_replace == 0 
                continue; 
            end
            [~,sorted_idx] = sort(fitness,'descend');
            worst_idx = sorted_idx(1:num_replace);
            worst_idx = safeIdx(worst_idx, size(X,2));
            X(:,worst_idx) = new_X(:,1:num_replace);
            fitness(worst_idx) = new_f(1:num_replace);
            currentFEs = currentFEs + lambda;
            improved = new_f(1:num_replace) < old_fitness(worst_idx);
            cma_success = cma_success + nnz(improved); 

        case 2 % IPM
            promising = fitness < prctile(fitness,30);
            idx = find(promising); 
            idx = idx(1:min(5,end));
            for i=idx'
                [x_opt,f_opt,~,out]=fmincon(fhd_col,X(:,i)',[],[],[],[],...
                    x_min*ones(1,D),x_max*ones(1,D),[],...
                    optimoptions('fmincon','Algorithm','interior-point',...
                    'MaxIter',ceil(scale*20),'Display','off'));
                currentFEs = currentFEs + out.funcCount;
                if f_opt<fitness(i)
                    X(:,i) = x_opt'; 
                    fitness(i) = f_opt; 
                    improved = true;
                end
            end
            ipm_success = ipm_success + double(improved);

        case 3 % LS2
            [Gbest,Gbest_f,currentFEs,succ]=LS2(Gbest,Gbest_f,currentFEs,func_num,maxFEs);
            if succ
                idx = randi(size(X,2));
                X(:,idx) = Gbest; 
                fitness(idx) = Gbest_f; 
                improved = true;
            end
            sqp_success = sqp_success + double(improved);

        case 4 % SHAF
            [~,idx] = sort(fitness); 
            idx = safeIdx(idx, size(X,2));
            elite1 = X(:,idx(1)); 
            elite2 = X(:,idx(2)); 
            elite3 = X(:,idx(3));
            a = 1.5*(1-t); 
            stagnant = fitness >= Pbest_f & (currentFEs>0.3*maxFEs);
            st_idx = find(stagnant); 
            st_idx = safeIdx(st_idx, size(X,2));
            
            st_idx = st_idx(1:min(ceil(scale*numel(st_idx)), numel(st_idx)));
            
            for i_idx = 1:numel(st_idx)
                i = st_idx(i_idx);
                r = rand(D,1);
                X1 = elite1+a*r.*abs(r.*elite1-X(:,i));
                X2 = elite2+a*r.*abs(r.*elite2-X(:,i));
                X3 = elite3+a*r.*abs(r.*elite3-X(:,i));
                X_new = (X1 + X2 + X3)/3;  
                X_new = max(min(X_new, x_max), x_min);
                f_new = fhd_col(X_new);  
                currentFEs=currentFEs+1;
                if f_new<fitness(i) 
                    X(:,i) = X_new; 
                    fitness(i) = f_new; 
                    improved = true; 
                end
            end
            shaf_success = shaf_success + double(improved);
        end
        
        % POPULATION SIZE SYNC 
        fitness = fitness(1:size(X,2));

        %% Update Pbest / Gbest 
        improved_p = fitness < Pbest_f;
        Pbest(:,improved_p) = X(:,improved_p);
        Pbest_f(improved_p) = fitness(improved_p);
        [new_Gbest,idx] = min(fitness);
        if new_Gbest < Gbest_f
            Gbest_f = new_Gbest;  
            Gbest = X(:,idx);  
            stagnation = 0;
        else
            stagnation = stagnation + 1;
        end

        %% Update probabilities
        total_success = pso_success + cma_success + ipm_success + sqp_success + shaf_success + 1e-10;
        success_vec = [pso_success, cma_success, ipm_success, sqp_success, shaf_success];
        Probs = success_vec / max(total_success,1);
        Probs = max(0.01,min(0.99,Probs));

        %% Reward & next state
        delta_best = max(0, prev_Gbest - Gbest_f);
        diversity_now = std(fitness)/max(mean(fitness), eps);
        diversity_gain = diversity_now - diversity;
        boundary_safe = max(0, min(1, boundary_viol));
        r = 0.7*delta_best + 0.2*diversity_gain + 0.1*(1-boundary_safe);
        r = max(-1,min(1,r));

        next_state = get_state_vector(X, fitness, t, Probs(1), Probs(2), boundary_safe, stagnation>5);
        norm_val = norm(next_state);
        if norm_val<eps
            next_state = [0.1, t, 0.2, 0.2, 0, 0, log10(D)]; 
            norm_val = norm(next_state); 
        end
        next_norm = next_state/norm_val;
        idx_raw = discretize(next_norm, edges);
        
        if isempty(idx_raw)||~isscalar(idx_raw) 
            next_idx = 1;
        else
            next_idx=max(1,min(1000,round(min(idx_raw,1000)))); 
        end

        if next_idx > size(agent.Q,1)
            next_idx = size(agent.Q,1);
        end

        agent.update(state_idx,action,r,next_idx);
        prev_Gbest = Gbest_f;

        %% Record
        while record_idx <= progress && currentFEs >= FEs_at_record(record_idx)
            recordedScores(record_idx) = Gbest_f;
            record_idx = record_idx + 1;
        end
    end

    %% CMA-ES refiner
    max_refine_FEs = max(100*D, 0.01*maxFEs);
    sigma_ref = 0.001*(x_max-x_min);
    lambda_ref = round(max(4, 4 + floor(3*log(D))));
    refine_budget = 0;  
    stall = 0;  
    prev_Gbest = Gbest_f;

    cma_ref = CMAES(D, Gbest, sigma_ref); % restart from best
    while refine_budget < max_refine_FEs
        [X_ref, f_ref, cma_ref] = cma_ref.step(lambda_ref, x_min, x_max, fhd_col);
        refine_budget = refine_budget + lambda_ref;
        [fmin_ref, idx_ref] = min(f_ref);
        if fmin_ref < Gbest_f
            Gbest_f = fmin_ref;  
            Gbest = X_ref(:, idx_ref);  
            stall = 0;
        else
            stall = stall + 1;  
            if stall==3
                break; 
            end
        end
        prev_Gbest = Gbest_f;
    end

    %% Final output 
    fmin = Gbest_f;
    if record_idx<=progress 
        recordedScores(record_idx:end) = fmin; 
    end
end

%% Helper functions
function state_vec = get_state_vector(X, fitness, t, pso_rate, cma_rate, boundary_viol, is_stagnant)
    diversity = std(fitness)/max(mean(fitness), eps);
    state_vec = [diversity, t, pso_rate, cma_rate, boundary_viol, is_stagnant, log10(size(X,1))];
end

function idx = safeIdx(idx, maxIdx)
    idx = max(1, min(maxIdx, idx));
end