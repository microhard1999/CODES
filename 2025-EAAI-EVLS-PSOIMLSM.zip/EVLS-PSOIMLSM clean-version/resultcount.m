results = zeros(1,30);

for D = [ 50 ] %
    for j=1:30 % runs
       
     
        

        
        
        filename=sprintf('result/EVLS_PSOIMLSM_problem%s_dim%s',num2str(j),num2str(D));
        resultc = load(filename,'result');
        results = mean(resultc.result);
        

    end 
    filename2=sprintf('EVLS_PSOIMLSM_problem__dim%s',num2str(D));
    save(filename2,'results');
end  