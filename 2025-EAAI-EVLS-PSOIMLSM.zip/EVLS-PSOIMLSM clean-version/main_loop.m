clear;
clc;
runs=51;
result=zeros(runs,30);
allerrorvals=zeros(1000,51);
range=[-100,100];
for D = [ 50      ]
    for i=1:30 % problem

    func_num=i;
    run_funcvals=[];
    for j=1:runs % runs
        fprintf('run =\t %d pro=%d dim=%d\n',j,i,D);
       [best_ans]=EVLS_PSOIMLSM(40,D,D*10000,range,func_num);  
        fprintf('%1.9e\n',best_ans);
        % fprintf('bestval =\t %d\n',best_ans);
        result(j,i)=best_ans;       
        filename=sprintf('result/EVLS_PSOIMLSM_problem%s_dim%s',num2str(i),num2str(D));
        save(filename,'result');
       %fdb+NLR+1.1
    end 
   mena=mean(result(:,i))
   end
end      
  

