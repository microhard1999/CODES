function [best_ans]=EVLS_PSOIMLSM(NP,dim,max_FES,range,func_num)
    %% parameter initialization
    Xmax=range(2);
    Xmin=range(1);
    succ=1;
    w_max=0.9;w_min=0.4;
    pro_ls=0.07;
    pro_ms=0.7;
    %% population initialization and evaluation
    pos=Xmin+(Xmax-Xmin).*rand(NP,dim);
    fitness=cec17_func(pos',func_num);
    fitness=fitness';
    pcount=2;
    gcount=2;
    fitcount=NP;
    pbest_pos=pos;
    pbest_val=fitness;
    [gbest_val,gbest_id]=min(pbest_val);
    gbest_pos=pbest_pos(gbest_id,:);
    gbestrep = repmat(gbest_pos,NP,1);
    Vmax = 30;
    Vmin = -Vmax;
    V= Vmin+(Vmax-Vmin).*rand(NP,dim);
    ratio=0.5;
    T=0;
    iter=1;
    BPART_pos(1,:)=gbest_pos;
    BPART_val(1)=gbest_val;
    BPART_pos(2,:)=gbest_pos;
    BPART_val(2)=gbest_val;
    CPART_pos(1,:)=gbest_pos;
    CPART_val(1,:)=gbest_val;
    ocount=zeros(1,NP);
    while fitcount<max_FES
        T=T+1;
        %% sort by fitness
        [~,index]=sort(fitness);
        pos = pos(index,:);
        V = V(index,:);
        pbest_pos = pbest_pos(index,:);
        pbest_val = pbest_val(index);
        OO=zeros(1,dim);
        ocount=ocount(1,index);
        %% parameter initialization
        w = w_max - (w_max-w_min)*fitcount / max_FES;
        c1 =(2.5-2*fitcount / max_FES);
        r1 = rand(1,1);
        r2 = rand(1,1);
        u=randperm(NP/2,2);
        for j=1:NP/2
            [U,index]=min(pbest_val(u));
            if min(pbest_val(u))<pbest_val(j)
                Ubest(j,:)=pbest_pos(index,:);
            else
                Ubest(j,:)=pbest_pos(j,:);
            end
        end
        p1 = Ubest; 
        %% from EOPSO (5)(6)(7)
        for j=1:NP/2
            if fitness(j)>0
                f(j)=1/(fitness(j)+1);
            else
                f(j)=1+abs(fitness(j));
            end
        end
        for j=1:NP/2
            OO=OO+f(j)/sum(f)*pbest_pos(j,:);
        end
        %% lose
        for i=NP/2+1:NP
            %% get from B group
            a=ceil(length(BPART_val)*rand);
            b=ceil(length(BPART_val)*rand);
            while a==b
               a=ceil(length(BPART_val)*rand);
               b=ceil(length(BPART_val)*rand);
            end
            if BPART_val(a)>BPART_val(b)
                a=b;
            end
            %% get from C group
            if length(CPART_val)>1
                c=ceil(length(CPART_val)*rand);
                d=ceil(length(CPART_val)*rand);
                while c==d
                    c=ceil(length(CPART_val)*rand);
                    d=ceil(length(CPART_val)*rand);
                end
                if CPART_val(c)>CPART_val(d)
                    b=d;
                else
                    b=c;
                end
            else
                b=1;
            end
            %% get from A group
            c=ceil(NP/2*rand);
            q=ceil(NP/2*rand);
            while c==q
                c=ceil(NP/2*rand);
                q=ceil(NP/2*rand);
            end
            if  fitness(q)<fitness(c)
                c=q;
            end
            if fitness(i)<mean(fitness(NP/2+1:NP))
                %% inspried by MPSO (11)
                V(i,:)=w.*V(i,:)+r1.*(p1(i-20,:)-pos(i,:))+c1*r2.*(repmat(mean(pbest_pos),1,1)-pos(i,:));
            else %% inspried by case 2, case 3 from EAPSO
                if BPART_val(a)<CPART_val(b) && BPART_val(a)<fitness(c) 
                    V(i,:)=w.*V(i,:)+r1.*(BPART_pos(a,:)-pos(i,:))+c1*rand(1,dim).*(OO-pos(i,:));
                elseif BPART_val(a)>CPART_val(b) && CPART_val(b)<fitness(c)
                    V(i,:)=w.*V(i,:)+r1.*(CPART_pos(b,:)-pos(i,:))+c1*rand(1,dim).*(OO-pos(i,:));
                end
            end
            pos(i,:)=pos(i,:)+V(i,:);
            %% boundary processing function
            pos(i,:) = ((pos(i,:)>=Xmin)&(pos(i,:)<=Xmax)).*pos(i,:)...
                    +(pos(i,:)<Xmin).*(Xmin+0.25.*(Xmax-Xmin).*rand(1,dim))+...
                    +(pos(i,:)>Xmax).*(Xmax-0.25.*(Xmax-Xmin).*rand(1,dim));
            fitness(i)=cec17_func(pos(i,:)',func_num);
            fitness(i)=fitness(i)';   
            fitcount=fitcount+1;
            %% update pbest and B group     
            if fitness(i)<pbest_val(i)
                pbest_pos(i,:)=pos(i,:);
                pbest_val(i)=fitness(i);
                pcount=pcount+1;               
                if pcount<=NP
                    BPART_pos(pcount,:)=pos(i,:);
                    BPART_val(pcount,:)=fitness(i);
                else
                    a=randperm(NP,1);
                    b=randperm(NP,1);
                    while a==b
                        a=randperm(NP,1);
                        b=randperm(NP,1);
                    end
                    if BPART_val(a,:)<BPART_val(b,:)
                        if fitness(i)<BPART_val(b,:)
                            BPART_val(b,:)=fitness(i);
                            BPART_pos(b,:)=pos(i,:);
                        end
                    else
                        if fitness(i)<BPART_val(a,:)
                            BPART_val(a,:)=fitness(i);
                            BPART_pos(a,:)=pos(i,:);
                        end
                    end
                end
            end
            %% update gbest
            if fitness(i)<gbest_val
                gbest_val=fitness(i);
                gbest_pos=pos(i,:);
            end
        end
         [~,gbest_id]=min(pbest_val);
         %% mutation
         if rand<0.7 && fitcount>0.5*max_FES
            E =sqrt(fitcount/max_FES);
            A=randperm(NP);
            tt=ceil(rand*NP);             
            for j=1:dim
                if (rand<0.3366) && (rand<E)
                    pos(tt,j)=pos(tt,j)+sin(rand*pi)*(pos(tt,j)-pos(A(tt),j));
                end
            end
         end
        %% update c group
        gcount=gcount+1;
        if gcount<=NP
            CPART_val(gcount)= gbest_val;
            CPART_pos(gcount,:)=gbest_pos;
        else
            a=randperm(length(CPART_val),1);
            b=randperm(length(CPART_val),1);
            while a==b
                a=randperm(length(CPART_val),1);
                b=randperm(length(CPART_val),1);
            end
            if CPART_val(b)>CPART_val(a)
                a=b;
            end
            if  gbest_val<CPART_val(a)
                CPART_val(a)= gbest_val;
                CPART_pos(a,:)= gbest_pos;
            end   
        end 

        %% boundary processing function
        pos = ((pos>=Xmin)&(pos<=Xmax)).*pos...
                +(pos<Xmin).*(Xmin+0.25.*(Xmax-Xmin).*rand(NP,dim))+...
                +(pos>Xmax).*(Xmax-0.25.*(Xmax-Xmin).*rand(NP,dim));

        %% local search: SQP
        if rand<pro_ls && fitcount>0.4*max_FES
            rk1=floor(NP*rand)+1;
            %% apply ISCA
            if succ==1
                mbest_pos=gbest_pos;
                mbest_val=gbest_val;
            else
                a = 2;
                r1=a-fitcount*((a)/max_FES);
                r2=(2*pi)*rand();
                r3=2*rand;
                r4=rand();
                if r4<0.5
                    mbest_pos=gbest_pos+(r1*sin(r2)*(r3*gbest_pos-pbest_pos(rk1,:)));
                    fitness2=cec17_func(mbest_pos',func_num);
                    mbest_val=fitness2';
                    if gbest_val>mbest_val
                        gbest_val=mbest_val;
                        gbest_pos=mbest_pos;
                        pos(gbest_id,:)=mbest_pos;
                        fitness(gbest_id)=mbest_val;
                        pbest_pos(gbest_id,:)=mbest_pos;
                        pbest_val(gbest_id,:)=mbest_val;
                    end
                    fitcount=fitcount+1;
                else          
                    mbest_pos=gbest_pos+(r1*cos(r2)*(r3*gbest_pos-pbest_pos(rk1,:)));
                    fitness2=cec17_func(mbest_pos',func_num);
                    mbest_val=fitness2';
                    if gbest_val>mbest_val
                        gbest_val=mbest_val;
                        gbest_pos=mbest_pos;
                        pos(gbest_id,:)=mbest_pos;
                        fitness(gbest_id)=mbest_val;
                        pbest_pos(gbest_id,:)=mbest_pos;
                        pbest_val(gbest_id,:)=mbest_val;
                    end
                    fitcount=fitcount+1;
                end
            end
            %% apply SQP
            [new_pos,new_val,fitcount,succ,flags]=local_search2(mbest_pos,...
            gbest_val,fitcount,func_num,max_FES,Xmin,Xmax,dim);
            new_pos=new_pos';        
            if succ==1  % if improved
                pro_ls=0.1*fitcount/max_FES;      
                pos(gbest_id,:)=new_pos;
                fitness(gbest_id)=new_val;
                pbest_pos(gbest_id,:)=new_pos;
                pbest_val(gbest_id,:)=new_val;
                gbest_pos=new_pos;
                gbest_val=new_val;            
            else  % not improved
                pro_ls=0.03;         
            end
        end
        iter=iter+1;
    end
    best_ans=gbest_val-func_num*100;  % Calculate the error   
end