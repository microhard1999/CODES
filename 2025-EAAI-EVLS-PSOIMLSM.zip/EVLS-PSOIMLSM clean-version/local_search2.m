function [new_pos,new_val,fitcount,succ,flagls] = local_search2(gbest_pos,gbest_val,fitcount,func_num,max_FES,Xmin,Xmax,dim)

    Xmin=repmat(Xmin,1,dim);
    Xmax=repmat(Xmax,1,dim);
    
    
    LS_FE=ceil(20.0000e-003*max_FES );
   
    options=optimset('Display','off','algorithm','sqp',...
        'UseParallel','never','MaxFunEvals',LS_FE) ;
    
    [new_pos, new_val , ~ , details]=fmincon(@cec17_func, gbest_pos',[],[],[],[],Xmin,Xmax,[],options,func_num);
    
    % check if there is an improvement in the fitness value
    if (gbest_val-new_val)>0
        succ=1;  % improved
        flagls=1;
    else
        succ=0;
        new_pos=gbest_pos;
        new_val=gbest_val;
        flagls=0;
    end
    
    % update FEs
    fitcount=fitcount+details.funcCount;

end


