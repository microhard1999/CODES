Paper Title: An ensemble velocity learning strategy for particle swarm optimization integrating multiple local search mechanisms

https://www.sciencedirect.com/science/article/pii/S0952197625011182?dgcid=author

Anyone clicking on this link (https://authors.elsevier.com/a/1lCFV3OWJ9CTlk) before July 22, 2025 will be taken directly to the final version of your article on ScienceDirect, which they are welcome to read or download.

Volume 156, Part C, 15 September 2025, 111117