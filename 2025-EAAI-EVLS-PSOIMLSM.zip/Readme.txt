Paper Title: An ensemble velocity learning strategy for particle swarm optimization integrating multiple local search mechanisms

https://www.sciencedirect.com/science/article/abs/pii/S0952197625011182

Volume 156, Part C, 15 September 2025, 111117