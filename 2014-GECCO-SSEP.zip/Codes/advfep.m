function advfep()
clear all;
rand('state',sum(100*clock));
randn('state',sum(100*clock));
normrnd('state',sum(100*clock));

global FUNCTION_EVALUATION;
global PROB_VECTOR;
global PROB_XU;
global PROB_XL;

PROBLEM_NO     =    10;
problem_init(PROBLEM_NO,30);

ITERATION = 50;
POP_NO    = 100;
MAX_GENERATION = 1500;
TOURNAMENT_SIZE= 10;

lower_bound = 1e-3;
tau  = 1/sqrt(2*sqrt(PROB_VECTOR));
tau1 = 1/sqrt(2*PROB_VECTOR);

% Initial probability for left side mutation operator
p = 0.3;
beta = 0;
gamma = 1;
delta = 0;
alpha  = 1;
rightalpha = 1.5;
% Calculate the probability of left side mutation operator
leftmut = floor(p*100);
par = 0;
SIGMA = 1;
muttype = 1;


for no_run = 1:ITERATION % perform idx independent runs
    % Initialization
    FUNCTION_EVALUATION = 0;
    pnteta = repmat(3, POP_NO, PROB_VECTOR);
    for i = 1:POP_NO
        pntx(i,:) = rand(1,PROB_VECTOR).*(PROB_XU-PROB_XL) + PROB_XL;
        pntf(i)   = fitness(PROBLEM_NO,pntx(i,:));
    end
    avgstepsizegen = 0;
    for idx = 1:MAX_GENERATION
        % Prepare for probability
        for i = 1:POP_NO
            indtype(i) = 0;
            stepsize(i) = 0;
        end 
        
        % Mutation and evaluation        
        for kk = 1:POP_NO
            a_normal = randn(1);
            pnteta(POP_NO+kk,:) = pnteta(kk,:).*exp(tau1*a_normal+tau*randn(1,PROB_VECTOR));
            for i = 1:PROB_VECTOR               
                if pnteta(POP_NO+kk,i) < lower_bound
                    pnteta(POP_NO+kk,i) = lower_bound;
                end
            end
            
            switch muttype
              case {1}
                pntx(POP_NO+kk,:) = pntx(kk,:) + pnteta(POP_NO+kk,:).*cauchy(1,PROB_VECTOR);
              %case {1}
              %  pntx(POP_NO+kk,:) = pntx(kk,:) + pnteta(POP_NO+kk,:).*stblrnd(alpha,beta,gamma,delta,PROB_VECTOR,1)';
              %case {2}
              %  pntx(POP_NO+kk,:) = pntx(kk,:) + pnteta(POP_NO+kk,:).*stblrnd(rightalpha,beta,gamma,delta,PROB_VECTOR,1)';
              case {3}
                pntx(POP_NO+kk,:) = pntx(kk,:) + pnteta(POP_NO+kk,:).*normrnd(0,SIGMA,1, PROB_VECTOR);      
            end
            
            % set individual type, 0 is parent, 1 is offspring
            indtype(POP_NO+kk) = 1;
            
            %temp(kk,:) = pntx(POP_NO+kk,:) -  pntx(kk,:);
            %stepsize(POP_NO+kk) = sum(abs(temp(kk,:)))/PROB_VECTOR;
            
            for i = 1:PROB_VECTOR               
                if pntx(POP_NO+kk,i) > PROB_XU
                    pntx(POP_NO+kk,i) = PROB_XU(i);
                end
                if pntx(POP_NO+kk,i) < PROB_XL
                    pntx(POP_NO+kk,i) = PROB_XL(i);
                end
            end
            
            temp(kk,:) = pntx(POP_NO+kk,:) -  pntx(kk,:);
            stepsize(POP_NO+kk) = sum(abs(temp(kk,:)))/PROB_VECTOR;
            
            pntf(POP_NO+kk) = fitness(PROBLEM_NO,pntx(POP_NO+kk,:));
        end
        
        % Tournament selection
        for kk = 1:POP_NO*2
            win(kk) = 0;
            for i = 1:TOURNAMENT_SIZE
                win(kk) = win(kk) - (pntf(kk) < pntf(ceil(rand(1)*POP_NO*2)));
            end
        end      
        
        sort_chd = sortrows([pntx,pntf',pnteta,win',indtype',stepsize'],PROB_VECTOR*2+2);
        pntx  = sort_chd(1:POP_NO,1:PROB_VECTOR);
        pntf  = sort_chd(1:POP_NO,PROB_VECTOR+1)';
        pnteta= sort_chd(1:POP_NO,PROB_VECTOR+2:PROB_VECTOR*2+1);
        win   = sort_chd(1:POP_NO,PROB_VECTOR*2+2)';
        indtype = sort_chd(1:POP_NO,PROB_VECTOR*2+3)';
        stepsize = sort_chd(1:POP_NO,PROB_VECTOR*2+4)';
        
        par = 0; offspring = 0; big = 0;
        totalsize = 0;
        for i=1:POP_NO
            switch indtype(i)
              case {0}
                par = par + 1;
              case {1}
                offspring = offspring + 1;
                totalsize = totalsize + stepsize(i);
                %if stepsize(i)>1
                %    big = big + 1;
                %end
            end
        end
        
        % save step size for each generation
        if offspring~=0
            avgstepsizegen(idx) = totalsize/offspring;
        else
            avgstepsizegen(idx) = 0;
        end
        % average the step size from generation 1 to idx
        avgstepsize = sum(avgstepsizegen)/idx;
        
        % long step size benchmark
        %lssb = PROB_XU(1)/100;
        if avgstepsizegen(idx)<=1e-2 && avgstepsizegen(idx)>1e-4 && avgstepsize>150*avgstepsizegen(idx)
            muttype = 3;
            SIGMA = 0.1;
        elseif avgstepsizegen(idx)<=1e-4 && avgstepsizegen(idx)>0 && avgstepsize>150*avgstepsizegen(idx)
            muttype = 3;
            SIGMA = 0.01;
        elseif avgstepsize>1 || avgstepsize<150*avgstepsizegen(idx)
            muttype = 1;
            %alpha = 1;
        else%if avgstepsize<=1
            muttype = 3;
            SIGMA = avgstepsize;
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % This solution good for f1 and f2
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %if avgstepsizegen(idx)<9e-3 && avgstepsizegen(idx)>1e-4
        %    muttype = 3;
        %    SIGMA = 0.1;
        %elseif avgstepsizegen(idx)<=1e-4 && avgstepsizegen(idx)>=0
        %    muttype = 3;
        %    SIGMA = 0.01;
        %elseif avgstepsize>1
        %    muttype = 1;
        %    alpha = 1;
        %elseif(avgstepsize<=1&&avgstepsize>0.1)
        %    muttype = 3;
        %    SIGMA = avgstepsize;
        %end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        gpdist(no_run,idx) = mean(pntf);
        
        %disp(strcat('muttype=',num2str(muttype),',SIGMA=',num2str(SIGMA),',avgstepsizegen=',num2str(avgstepsizegen(idx)),',avgstepsize=',num2str(avgstepsize),',par=',num2str(par),',offspring=',num2str(offspring)));
        %disp(strcat(num2str(idx),',',num2str(pntf(1)),',',num2str(mean(pntf),'%.12f')));
        %fprintf(fid,'%d,%.12e,%.12e\n',idx,pntf(1),mean(pntf));
    end
    disp(strcat(num2str(idx),',',num2str(pntf(1)),',',num2str(mean(pntf),'%.12f')));
    %result(no_run)=mean(pntf);
    %fprintf(fid,'%.12e %.12e\n',pntx(1,1),pntx(1,2));
    all_min(no_run) = pntf(1);
    all_mean(no_run)= mean(pntf);
end
%disp(num2str(mean(result)));
for j = 1:MAX_GENERATION
    n = 0;
    for i = 1:ITERATION
        n = n + gpdist(i,j);
    end
    gpdist50(j) = n/ITERATION;    
end
save('TestingResults7.mat', 'gpdist50');
%************************
disp(strcat('Completed!'));
