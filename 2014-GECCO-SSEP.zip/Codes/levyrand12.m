function C = levyrand12(xx, yy)

if nargin == 1, y = x; end
    %for i = 1:xx
        %for j = 1:yy
            alpha=1.2;
            alpha1=1.0/alpha;
            x=normrnd(0,0.878829,xx,yy);
            y=normrnd(0,1,xx,yy);
            v=x./(abs(y).^alpha1);
            w=(0.20519.*exp(-abs(v)./2.941)+1.0).*v;
            C = w;
        %end
    %end