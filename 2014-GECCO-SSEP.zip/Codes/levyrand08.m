function C = levyrand08(xx, yy)

if nargin == 1, y = x; end
    %for i = 1:xx
    %    for j = 1:yy
            alpha=0.8;
            alpha1=1.0/alpha;
            x=normrnd(0,1.13999,xx,yy);
            y=normrnd(0,1,xx,yy);
            v=x./(abs(y).^alpha1);
            w=((0.793112-1.0).*exp(-abs(v)./2.483)+1.0).*v;
            C = w;
            %C(i,j) = w;
    %    end
    %end